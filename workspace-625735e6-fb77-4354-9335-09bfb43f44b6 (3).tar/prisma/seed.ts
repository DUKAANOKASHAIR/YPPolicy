import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const schemes = [
  // Agriculture & Farmers
  {
    sector: "Agriculture & Farmers",
    schemeName: "PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)",
    nameHi: "पीएम-किसान (प्रधानमंत्री किसान सम्मान निधि)",
    description: "Direct income support of ₹6,000 per year to farmer families with cultivable land to supplement their financial needs for procuring various inputs related to agriculture.",
    descriptionHi: "खेती योग्य भूमि वाले किसान परिवारों को प्रतिवर्ष ₹6,000 की प्रत्यक्ष आय सहायता कृषि संबंधित विभिन्न आवश्यकताओं की पूर्ति के लिए।",
    eligibility: "All landholding farmer families (subject to certain exclusions). Families holding cultivable land as per land records. No income limit. Both rural and urban areas.",
    eligibilityHi: "सभी भूमि धारक किसान परिवार (कुछ बहिष्करणों के अधीन)। भूमि अभिलेखों के अनुसार खेती योग्य भूमि रखने वाले परिवार। कोई आय सीमा नहीं। ग्रामीण और शहरी दोनों क्षेत्र।",
    documents: "Aadhaar Card, Land Record/Khasra, Bank Account Details, Self-Declaration (if Aadhaar not available)",
    documentsHi: "आधार कार्ड, भूमि अभिलेख/खसरा, बैंक खाता विवरण, स्व-घोषणा (यदि आधार उपलब्ध न हो)",
    benefits: "₹6,000 per year per farmer family in three equal installments of ₹2,000 each, transferred directly to the bank account.",
    benefitsHi: "प्रति किसान परिवार प्रतिवर्ष ₹6,000, ₹2,000 की तीन समान किस्तों में सीधे बैंक खाते में स्थानांतरित।",
    applyLink: "https://pmkisan.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },
  {
    sector: "Agriculture & Farmers",
    schemeName: "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
    nameHi: "प्रधानमंत्री फसल बीमा योजना (पीएमएफबीवाई)",
    description: "Comprehensive crop insurance scheme providing financial support to farmers suffering crop loss/damage due to unforeseen events like natural calamities, pests, and diseases.",
    descriptionHi: "व्यापक फसल बीमा योजना जो प्राकृतिक आपदा, कीट और बीमारियों जैसी अप्रत्याशित घटनाओं के कारण फसल हानि/क्षति से पीड़ित किसानों को वित्तीय सहायता प्रदान करती है।",
    eligibility: "All farmers including sharecroppers and tenant farmers growing notified crops in notified areas. All categories (General/SC/ST/OBC).",
    eligibilityHi: "सभी किसान जिनमें बंटई और किरायेदार किसान शामिल हैं जो अधिसूचित क्षेत्रों में अधिसूचित फसलें उगाते हैं। सभी श्रेणियां (सामान्य/SC/ST/OBC)।",
    documents: "Aadhaar Card, Bank Account Details, Land Records, Crop Details, Photograph",
    documentsHi: "आधार कार्ड, बैंक खाता विवरण, भूमि अभिलेख, फसल विवरण, फोटोग्राफ",
    benefits: "Insurance coverage for Kharif and Rabi crops. Premium: 2% for Kharif, 1.5% for Rabi, 5% for Commercial/Horticultural crops. Rest borne by government.",
    benefitsHi: "खरीफ और रबी फसलों के लिए बीमा कवरेज। प्रीमियम: खरीफ के लिए 2%, रबी के लिए 1.5%, व्यावसायिक/बागवानी फसलों के लिए 5%। शेष सरकार वहन करती है।",
    applyLink: "https://pmfby.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },
  {
    sector: "Agriculture & Farmers",
    schemeName: "Soil Health Card Scheme",
    nameHi: "स्वास्थ्य कार्ड योजना",
    description: "Provides soil health cards to farmers carrying crop-wise recommendations of nutrients and fertilizers required for individual farms to improve productivity.",
    descriptionHi: "किसानों को मिट्टी स्वास्थ्य कार्ड प्रदान करती है जिसमें व्यक्तिगत खेतों की उत्पादकता बढ़ाने के लिए पोषक तत्वों और उर्वरकों की फसल-वार सिफारिशें होती हैं।",
    eligibility: "All farmers across India. No income or category restrictions. Both small and large landholding farmers can apply.",
    eligibilityHi: "भारत भर के सभी किसान। कोई आय या श्रेणी प्रतिबंध नहीं। छोटे और बड़े दोनों भूमि धारक किसान आवेदन कर सकते हैं।",
    documents: "Aadhaar Card, Land Record, Farm Details",
    documentsHi: "आधार कार्ड, भूमि अभिलेख, खेत विवरण",
    benefits: "Free soil testing and Soil Health Card with crop-specific fertilizer recommendations. Improves soil quality and increases farm productivity.",
    benefitsHi: "मुफ्त मिट्टी परीक्षण और फसल-विशिष्ट उर्वरक सिफारिशों के साथ मिट्टी स्वास्थ्य कार्ड। मिट्टी की गुणवत्ता में सुधार और खेत की उत्पादकता बढ़ाता है।",
    applyLink: "https://soilhealth.dac.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Education
  {
    sector: "Education",
    schemeName: "National Scholarship Portal (NSP)",
    nameHi: "राष्ट्रीय छात्रवृत्ति पोर्टल (NSP)",
    description: "One-stop solution for end-to-end scholarship processing covering various scholarship schemes for SC, ST, OBC, Minority, and Merit students.",
    descriptionHi: "SC, ST, OBC, अल्पसंख्यक और मेरिट छात्रों के लिए विभिन्न छात्रवृत्ति योजनाओं को कवर करने वाली अंत-से-अंत छात्रavृत्ति प्रसंस्करण के लिए वन-स्टॉप समाधान।",
    eligibility: "Students from SC/ST/OBC/Minority communities. Meritorious students from economically weaker sections. Annual family income up to ₹2.5 lakh.",
    eligibilityHi: "SC/ST/OBC/अल्पसंख्यक समुदायों के छात्र। आर्थिक रूप से कमजोर वर्गों से मेधावी छात्र। वार्षिक पारिवारिक आय ₹2.5 लाख तक।",
    documents: "Aadhaar Card, Income Certificate, Caste Certificate, Marksheets, Bank Passbook, Institution Fee Receipt, Bonafide Certificate",
    documentsHi: "आधार कार्ड, आय प्रमाण पत्र, जाति प्रमाण पत्र, अंकतालिका, बैंक पासबुक, संस्था शुल्क रसीद, बोनाफाइड प्रमाण पत्र",
    benefits: "Financial assistance ranging from ₹5,000 to ₹75,000 per year depending on course and category. Covers tuition fees, maintenance allowance, and other educational expenses.",
    benefitsHi: "पाठ्यक्रम और श्रेणी के आधार पर प्रतिवर्ष ₹5,000 से ₹75,000 तक की वित्तीय सहायता। शिक्षण शुल्क, रखरखाव भत्ता और अन्य शैक्षिक खर्चों को कवर करता है।",
    applyLink: "https://scholarships.gov.in/",
    ageMin: 5, ageMax: 35, incomeMax: 250000, category: "SC/ST/OBC/Minority"
  },
  {
    sector: "Education",
    schemeName: "PM POSHAN (Mid-Day Meal Scheme)",
    nameHi: "पीएम पोषण (मध्याह्न भोजन योजना)",
    description: "Provides free hot cooked meals to children studying in government and government-aided schools from Class 1 to 8 to improve nutritional status and encourage school enrollment.",
    descriptionHi: "सरकारी और सरकारी सहायता प्राप्त स्कूलों में कक्षा 1 से 8 तक पढ़ने वाले बच्चों को मुफ्त गर्म भोजन प्रदान करती है।",
    eligibility: "All children studying in Classes 1 to 8 in government/government-aided schools. No income limit. All categories (General/SC/ST/OBC).",
    eligibilityHi: "सरकारी/सरकारी सहायता प्राप्त स्कूलों में कक्षा 1 से 8 तक पढ़ने वाले सभी बच्चे। कोई आय सीमा नहीं। सभी श्रेणियां।",
    documents: "Aadhaar Card, School ID, Admission Certificate",
    documentsHi: "आधार कार्ड, स्कूल आईडी, प्रवेश प्रमाण पत्र",
    benefits: "Free nutritious hot cooked meal every school day. Helps in improving enrollment, attendance, and retention in schools. Special focus on nutrition for children.",
    benefitsHi: "प्रत्येक स्कूल दिवस पर मुफ्त पौष्टिक गर्म भोजन। स्कूल में नामांकन, उपस्थिति और बने रहने में सुधार। बच्चों के पोषण पर विशेष ध्यान।",
    applyLink: "https://education.gov.in/pm-poshan",
    ageMin: 6, ageMax: 14, incomeMax: null, category: "All"
  },
  {
    sector: "Education",
    schemeName: "Betee Bachao Beti Padhao (BBBP)",
    nameHi: "बेटी बचाओ बेटी पढ़ाओ (BBBP)",
    description: "National scheme to address declining child sex ratio, ensure survival, protection, and education of the girl child, and promote gender equality.",
    descriptionHi: "गिरते बाल लिंग अनुपात को दूर करने, बालिका के जीवन, संरक्षण और शिक्षा को सुनिश्चित करने और लैंगिक समानता को बढ़ावा देने के लिए राष्ट्रीय योजना।",
    eligibility: "Girl children across India. Focus on districts with low child sex ratio. All categories eligible.",
    eligibilityHi: "भारत भर की बालिकाएं। कम बाल लिंग अनुपात वाले जिलों पर ध्यान केंद्रित। सभी श्रेणियां पात्र।",
    documents: "Birth Certificate, Aadhaar Card, School Admission Documents",
    documentsHi: "जन्म प्रमाण पत्र, आधार कार्ड, स्कूल प्रवेश दस्तावेज",
    benefits: "Sukanya Samriddhi Account with higher interest rates. Scholarship for girl child education. Awareness campaigns for gender equality.",
    benefitsHi: "उच्च ब्याज दरों के साथ सुकन्या समृद्धि खाता। बालिका शिक्षा के लिए छात्रवृत्ति। लैंगिक समानता के लिए जागरूकता अभियान।",
    applyLink: "https://wcd.nic.in/bbbp-schemes",
    ageMin: 0, ageMax: 18, incomeMax: null, category: "All"
  },

  // Employment & Skill Development
  {
    sector: "Employment & Skill Development",
    schemeName: "Pradhan Mantri Kaushal Vikas Yojana (PMKVY)",
    nameHi: "प्रधानमंत्री कौशल विकास योजना (PMKVY)",
    description: "Skill development initiative to enable Indian youth to take up industry-relevant skill training to secure a better livelihood.",
    descriptionHi: "भारतीय युवाओं को बेहतर जीविका सुरक्षित करने के लिए उद्योग-प्रासंगिक कौशल प्रशिक्षण लेने में सक्षम बनाने की पहल।",
    eligibility: "Indian youth aged 18-35 years. School dropouts or unemployed youth. No minimum educational qualification required for short-term courses.",
    eligibilityHi: "18-35 वर्ष की आयु के भारतीय युवा। स्कूल छोड़ने वाले या बेरोजगार युवा। अल्पकालिक पाठ्यक्रमों के लिए न्यूनतम शैक्षिक योग्यता आवश्यक नहीं।",
    documents: "Aadhaar Card, Bank Account Details, Educational Qualification Certificate, Address Proof, Photograph",
    documentsHi: "आधार कार्ड, बैंक खाता विवरण, शैक्षिक योग्यता प्रमाण पत्र, पता प्रमाण, फोटोग्राफ",
    benefits: "Free skill training with certification. ₹500-₹1,000 per month training stipend. Placement assistance after training. Recognition of prior learning.",
    benefitsHi: "प्रमाणन के साथ मुफ्त कौशल प्रशिक्षण। प्रति माह ₹500-₹1,000 प्रशिक्षण भत्ता। प्रशिक्षण के बाद नियोजन सहायता। पूर्व शिक्षा की मान्यता।",
    applyLink: "https://pmkvyofficial.org/",
    ageMin: 18, ageMax: 35, incomeMax: null, category: "All"
  },
  {
    sector: "Employment & Skill Development",
    schemeName: "National Career Service (NCS) Portal",
    nameHi: "राष्ट्रीय करियर सेवा (NCS) पोर्टल",
    description: "Digital platform connecting job seekers with employers, providing career counseling, job matching, and employment opportunities across India.",
    descriptionHi: "नौकरी चाहने वालों को नियोक्ताओं के साथ जोड़ने वाला डिजिटल प्लेटफॉर्म, करियर परामर्श, नौकरी मिलान और रोजगार अवसर प्रदान करता है।",
    eligibility: "All job seekers aged 16 years and above. Registered unemployed youth. Students seeking internships. All categories.",
    eligibilityHi: "16 वर्ष और उससे अधिक आयु के सभी नौकरी चाहने वाले। पंजीकृत बेरोजगार युवा। इंटर्नशिप चाहने वाले छात्र। सभी श्रेणियां।",
    documents: "Aadhaar Card, Educational Certificates, Resume/CV, Experience Certificate (if any)",
    documentsHi: "आधार कार्ड, शैक्षिक प्रमाण पत्र, रिज्यूमे/CV, अनुभव प्रमाण पत्र (यदि कोई हो)",
    benefits: "Free job portal access. Career counseling services. Job matching based on skills. Information about job fairs and employment schemes.",
    benefitsHi: "मुफ्त नौकरी पोर्टल एक्सेस। करियर परामर्श सेवाएं। कौशल आधारित नौकरी मिलान। नौकरी मेलों और रोजगार योजनाओं की जानकारी।",
    applyLink: "https://www.ncs.gov.in/",
    ageMin: 16, ageMax: null, incomeMax: null, category: "All"
  },

  // Startup & Business
  {
    sector: "Startup & Business",
    schemeName: "Pradhan Mantri Mudra Yojana (PMMY)",
    nameHi: "प्रधानमंत्री मुद्रा योजना (PMMY)",
    description: "Provides loans up to ₹10 lakh to non-corporate, non-farm small/micro enterprises for income generating activities in manufacturing, trading, and services.",
    descriptionHi: "विनिर्माण, व्यापार और सेवाओं में आय उत्पादक गतिविधियों के लिए गैर-कॉर्पोरेट, गैर-खेती छोटे/सूक्ष्म उद्यमों को ₹10 लाख तक के ऋण प्रदान करती है।",
    eligibility: "Any Indian citizen who is engaged in non-farm income generating activity. No collateral needed for loans up to ₹10 lakh. All categories.",
    eligibilityHi: "कोई भी भारतीय नागरिक जो गैर-खेती आय उत्पादक गतिविधि में संलग्न है। ₹10 लाख तक के ऋण के लिए कोई संपार्श्विक नहीं। सभी श्रेणियां।",
    documents: "Aadhaar Card, PAN Card, Bank Account Details, Business Plan, Address Proof, Photograph, GST Registration (if applicable)",
    documentsHi: "आधार कार्ड, पैन कार्ड, बैंक खाता विवरण, व्यापार योजना, पता प्रमाण, फोटोग्राफ, GST पंजीकरण (यदि लागू हो)",
    benefits: "Shishu: Up to ₹50,000. Kishore: ₹50,000 to ₹5 lakh. Tarun: ₹5 lakh to ₹10 lakh. No collateral required. Subsidized interest rates.",
    benefitsHi: "शिशु: ₹50,000 तक। किशोर: ₹50,000 से ₹5 लाख। तरुण: ₹5 लाख से ₹10 लाख। कोई संपार्श्विक आवश्यक नहीं। अनुदानित ब्याज दरें।",
    applyLink: "https://www.mudra.org.in/",
    ageMin: 18, ageMax: 65, incomeMax: null, category: "All"
  },
  {
    sector: "Startup & Business",
    schemeName: "Startup India Seed Fund Scheme",
    nameHi: "स्टार्टअप इंडिया सीड फंड योजना",
    description: "Provides financial assistance to startups for proof of concept, prototype development, product trials, market entry, and commercialization.",
    descriptionHi: "प्रूफ ऑफ कॉन्सेप्ट, प्रोटोटाइप विकास, उत्पाद परीक्षण, बाजार प्रवेश और व्यावसायीकरण के लिए स्टार्टअप्स को वित्तीय सहायता प्रदान करती है।",
    eligibility: "Startups recognized by DPIIT. Incorporated for less than 2 years. Not received more than ₹10 lakh of monetary support from Government.",
    eligibilityHi: "DPIIT द्वारा मान्यता प्राप्त स्टार्टअप्स। 2 वर्ष से कम समय से शामिल। सरकार से ₹10 लाख से अधिक मौद्रिक सहायता प्राप्त नहीं की।",
    documents: "DPIIT Recognition Certificate, PAN Card, Bank Account Details, Business Plan, Aadhaar Card",
    documentsHi: "DPIIT मान्यता प्रमाण पत्र, पैन कार्ड, बैंक खाता विवरण, व्यापार योजना, आधार कार्ड",
    benefits: "Seed funding up to ₹20 lakh for validation/prototype. Up to ₹50 lakh for market entry. Mentorship and networking support.",
    benefitsHi: "सत्यापन/प्रोटोटाइप के लिए ₹20 लाख तक सीड फंडिंग। बाजार प्रवेश के लिए ₹50 लाख तक। मेंटरशिप और नेटवर्किंग सहायता।",
    applyLink: "https://www.startupindia.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Youth Development
  {
    sector: "Youth Development",
    schemeName: "Nehru Yuva Kendra Sangathan (NYKS)",
    nameHi: "नेहरू युवा केंद्र संगठन (NYKS)",
    description: "Youth club network that mobilizes youth for community development, leadership building, and participation in nation-building activities across India.",
    descriptionHi: "युवा क्लब नेटवर्क जो सामुदायिक विकास, नेतृत्व निर्माण और राष्ट्र निर्माण गतिविधियों में भागीदारी के लिए युवाओं को लामबंद करता है।",
    eligibility: "Indian youth aged 15-29 years. Members of youth clubs. Both rural and urban youth can participate.",
    eligibilityHi: "15-29 वर्ष की आयु के भारतीय युवा। युवा क्लबों के सदस्य। ग्रामीण और शहरी दोनों युवा भाग ले सकते हैं।",
    documents: "Aadhaar Card, Age Proof, Educational Certificate, Passport Size Photograph",
    documentsHi: "आधार कार्ड, आयु प्रमाण, शैक्षिक प्रमाण पत्र, पासपोर्ट साइज फोटो",
    benefits: "Training programs and workshops. Leadership development opportunities. Community service participation. Cultural and sports activities. Awareness campaigns.",
    benefitsHi: "प्रशिक्षण कार्यक्रम और कार्यशालाएं। नेतृत्व विकास अवसर। सामुदायिक सेवा भागीदारी। सांस्कृतिक और खेल गतिविधियां। जागरूकता अभियान।",
    applyLink: "https://nyks.nic.in/",
    ageMin: 15, ageMax: 29, incomeMax: null, category: "All"
  },
  {
    sector: "Youth Development",
    schemeName: "National Youth Parliament Festival",
    nameHi: "राष्ट्रीय युवा संसद महोत्सव",
    description: "Platform for youth to articulate their views on policy issues, practice parliamentary democracy, and develop debating and public speaking skills.",
    descriptionHi: "युवाओं के लिए नीतिगत मुद्दों पर अपने विचार व्यक्त करने, संसदीय लोकतंत्र का अभ्यास करने और बहस और सार्वजनिक भाषण कौशल विकसित करने का मंच।",
    eligibility: "Indian youth aged 18-25 years. Students and young professionals. All categories.",
    eligibilityHi: "18-25 वर्ष की आयु के भारतीय युवा। छात्र और युवा पेशेवर। सभी श्रेणियां।",
    documents: "Aadhaar Card, Educational Certificate, Age Proof",
    documentsHi: "आधार कार्ड, शैक्षिक प्रमाण पत्र, आयु प्रमाण",
    benefits: "National level recognition. Platform to discuss policy issues. Interaction with parliamentarians and policy makers. Certificates and awards.",
    benefitsHi: "राष्ट्रीय स्तर पर मान्यता। नीतिगत मुद्दों पर चर्चा का मंच। संसद सदस्यों और नीति निर्माताओं के साथ बातचीत। प्रमाण पत्र और पुरस्कार।",
    applyLink: "https://nypf.mygov.in/",
    ageMin: 18, ageMax: 25, incomeMax: null, category: "All"
  },

  // Women Empowerment
  {
    sector: "Women Empowerment",
    schemeName: "Pradhan Mantri Matru Vandana Yojana (PMMVY)",
    nameHi: "प्रधानमंत्री मातृ वंदना योजना (PMMVY)",
    description: "Maternity benefit program providing cash compensation to pregnant and lactating women for wage loss during pregnancy and to improve health and nutrition.",
    descriptionHi: "गर्भावस्था के दौरान मजदूरी हानि के लिए गर्भवती और स्तनपान कराने वाली महिलाओं को नकद मुआवजा प्रदान करने वाली प्रसूति लाभ कार्यक्रम।",
    eligibility: "Pregnant and lactating women (first live birth). Age 19 years and above. Registered at Anganwadi center. Not a government employee.",
    eligibilityHi: "गर्भवती और स्तनपान कराने वाली महिलाएं (पहली सजीव जन्म)। 19 वर्ष और उससे अधिक आयु। आंगनबाड़ी केंद्र में पंजीकृत। सरकारी कर्मचारी नहीं।",
    documents: "Aadhaar Card, Bank Account, MCP Card, Ration Card, Mobile Number",
    documentsHi: "आधार कार्ड, बैंक खाता, MCP कार्ड, राशन कार्ड, मोबाइल नंबर",
    benefits: "₹5,000 in three installments. First installment at registration. Second after 6 months of pregnancy. Third after child birth registration.",
    benefitsHi: "तीन किस्तों में ₹5,000। पहली किस्त पंजीकरण पर। दूसरी गर्भावस्था के 6 महीने बाद। तीसरी बच्चे के जन्म पंजीकरण के बाद।",
    applyLink: "https://pmmvy.gov.in/",
    ageMin: 19, ageMax: 45, incomeMax: null, category: "All"
  },
  {
    sector: "Women Empowerment",
    schemeName: "Mahila Shakti Kendra (MSK)",
    nameHi: "महिला शक्ति केंद्र (MSK)",
    description: "Empowers rural women through community participation, skill development, and access to various government schemes at the grassroots level.",
    descriptionHi: "सामुदायिक भागीदारी, कौशल विकास और जमीनी स्तर पर विभिन्न सरकारी योजनाओं तक पहुंच के माध्यम से ग्रामीण महिलाओं को सशक्त बनाता है।",
    eligibility: "Rural women across India. Women from all categories. Focus on women from backward districts and aspirational districts.",
    eligibilityHi: "भारत भर की ग्रामीण महिलाएं। सभी श्रेणियों की महिलाएं। पिछड़े जिलों और आकांक्षी जिलों की महिलाओं पर ध्यान।",
    documents: "Aadhaar Card, Address Proof, Ration Card, Photograph",
    documentsHi: "आधार कार्ड, पता प्रमाण, राशन कार्ड, फोटोग्राफ",
    benefits: "Skill training for livelihood. Awareness about rights and entitlements. Facilitation of government schemes. Community mobilization support.",
    benefitsHi: "जीविका के लिए कौशल प्रशिक्षण। अधिकारों और भत्तों के बारे में जागरूकता। सरकारी योजनाओं की सुविधा। सामुदायिक लामबंदी सहायता।",
    applyLink: "https://wcd.nic.in/mahila-shakti-kendra",
    ageMin: 18, ageMax: 60, incomeMax: null, category: "All"
  },

  // Child Welfare
  {
    sector: "Child Welfare",
    schemeName: "Integrated Child Development Services (ICDS)",
    nameHi: "समग्र बाल विकास सेवाएं (ICDS)",
    description: "Comprehensive program providing nutrition, immunization, health check-up, and preschool education services to children under 6 years and pregnant/lactating women.",
    descriptionHi: "6 वर्ष से कम उम्र के बच्चों और गर्भवती/स्तनपान कराने वाली महिलाओं को पोषण, टीकाकरण, स्वास्थ्य जांच और पूर्वस्कूली शिक्षा सेवाएं प्रदान करने वाला व्यापक कार्यक्रम।",
    eligibility: "Children below 6 years. Pregnant and lactating women. Adolescent girls (14-18 years). All categories.",
    eligibilityHi: "6 वर्ष से कम आयु के बच्चे। गर्भवती और स्तनपान कराने वाली महिलाएं। किशोरी लड़कियां (14-18 वर्ष)। सभी श्रेणियां।",
    documents: "Birth Certificate, Aadhaar Card, Ration Card, Mother's ID Proof",
    documentsHi: "जन्म प्रमाण पत्र, आधार कार्ड, राशन कार्ड, माता का पहचान पत्र",
    benefits: "Supplementary nutrition (take-home rations). Immunization. Health check-ups. Referral services. Pre-school education at Anganwadi centers.",
    benefitsHi: "पूरक पोषण (घर ले जाने वाले राशन)। टीकाकरण। स्वास्थ्य जांच। रेफरल सेवाएं। आंगनबाड़ी केंद्रों पर पूर्व-स्कूली शिक्षा।",
    applyLink: "https://icds-wcd.nic.in/",
    ageMin: 0, ageMax: 6, incomeMax: null, category: "All"
  },

  // Health & Medical
  {
    sector: "Health & Medical",
    schemeName: "Ayushman Bharat Pradhan Mantri Jan Arogya Yojana (AB-PMJAY)",
    nameHi: "आयुष्मान भारत प्रधानमंत्री जन आरोग्य योजना (AB-PMJAY)",
    description: "World's largest government-funded healthcare program providing health cover of ₹5 lakh per family per year for secondary and tertiary hospitalization.",
    descriptionHi: "दुनिया का सबसे बड़ा सरकारी वित्त पोषित स्वास्थ्य सेवा कार्यक्रम जो माध्यमिक और तृतीयक अस्पताल भर्ती के लिए प्रति परिवार प्रतिवर्ष ₹5 लाख का स्वास्थ्य कवरेज प्रदान करता है।",
    eligibility: "Families listed in SECC 2011 database. Rural and urban deprived families. No cap on family size, age, or gender. Covers pre-existing conditions.",
    eligibilityHi: "SECC 2011 डेटाबेस में सूचीबद्ध परिवार। ग्रामीण और शहरी वंचित परिवार। परिवार के आकार, उम्र या लिंग पर कोई सीमा नहीं। पहले से मौजूद बीमारियों को कवर करता है।",
    documents: "Aadhaar Card, Ration Card, SECC Card, Mobile Number, Bank Account (optional)",
    documentsHi: "आधार कार्ड, राशन कार्ड, SECC कार्ड, मोबाइल नंबर, बैंक खाता (वैकल्पिक)",
    benefits: "₹5 lakh health cover per family per year. 1,500+ medical procedures covered. Cashless treatment at empaneled hospitals. Pre and post hospitalization expenses.",
    benefitsHi: "प्रति परिवार प्रतिवर्ष ₹5 लाख स्वास्थ्य कवरेज। 1,500+ चिकित्सा प्रक्रियाएं कवर। अनुबंधित अस्पतालों में नकद रहित उपचार। अस्पताल भर्ती से पहले और बाद के खर्च।",
    applyLink: "https://www.pmjay.gov.in/",
    ageMin: 0, ageMax: null, incomeMax: null, category: "BPL/SECC"
  },
  {
    sector: "Health & Medical",
    schemeName: "Pradhan Mantri Surakshit Matritva Abhiyan (PMSMA)",
    nameHi: "प्रधानमंत्री सुरक्षित मातृत्व अभियान (PMSMA)",
    description: "Free antenatal check-ups for pregnant women on the 9th of every month to ensure safe pregnancy and healthy motherhood.",
    descriptionHi: "सुरक्षित गर्भावस्था और स्वस्थ मातृत्व सुनिश्चित करने के लिए हर महीने की 9 तारीख को गर्भवती महिलाओं के लिए मुफ्त पूर्व प्रसूति जांच।",
    eligibility: "All pregnant women. Especially those in their 2nd and 3rd trimester. No income or category restrictions.",
    eligibilityHi: "सभी गर्भवती महिलाएं। विशेष रूप से जो अपने दूसरे और तीसरे तिमाही में हैं। कोई आय या श्रेणी प्रतिबंध नहीं।",
    documents: "Aadhaar Card, MCP Card, Bank Account Details",
    documentsHi: "आधार कार्ड, MCP कार्ड, बैंक खाता विवरण",
    benefits: "Free antenatal check-ups on 9th of every month. Free diagnostics and investigations. Free medicines and supplements. IFA tablets and calcium tablets.",
    benefitsHi: "हर महीने की 9 तारीख को मुफ्त पूर्व प्रसूति जांच। मुफ्त डायग्नोस्टिक्स और जांच। मुफ्त दवाइयां और पूरक। IFA गोलियां और कैल्शियम गोलियां।",
    applyLink: "https://pmsma.nhp.gov.in/",
    ageMin: 18, ageMax: 45, incomeMax: null, category: "All"
  },

  // Housing & Urban Development
  {
    sector: "Housing & Urban Development",
    schemeName: "Pradhan Mantri Awas Yojana - Urban (PMAY-U)",
    nameHi: "प्रधानमंत्री आवास योजना - शहरी (PMAY-U)",
    description: "Addresses urban housing shortage for EWS/LIG/MIG categories with credit-linked subsidy and in-situ slum rehabilitation.",
    descriptionHi: "EWS/LIG/MIG श्रेणियों के लिए क्रेडिट-लिंक्ड सब्सिडी और इन-सीटू झुग्गी पुनर्वास के साथ शहरी आवास की कमी को दूर करता है।",
    eligibility: "EWS (income up to ₹3 lakh/year), LIG (up to ₹6 lakh), MIG-I (up to ₹12 lakh), MIG-II (up to ₹18 lakh). Must not own a pucca house.",
    eligibilityHi: "EWS (आय ₹3 लाख/वर्ष तक), LIG (₹6 लाख तक), MIG-I (₹12 लाख तक), MIG-II (₹18 लाख तक)। पक्का मकान नहीं होना चाहिए।",
    documents: "Aadhaar Card, Income Certificate, PAN Card, Bank Account, Address Proof, Photograph",
    documentsHi: "आधार कार्ड, आय प्रमाण पत्र, पैन कार्ड, बैंक खाता, पता प्रमाण, फोटोग्राफ",
    benefits: "Interest subsidy of 3-6.5% on home loans. Central assistance up to ₹2.67 lakh. Slum rehabilitation with participation. Affordable housing in partnership.",
    benefitsHi: "गृह ऋण पर 3-6.5% ब्याज सब्सिडी। ₹2.67 लाख तक केंद्रीय सहायता। भागीदारी के साथ झुग्गी पुनर्वास। साझेदारी में किफायती आवास।",
    applyLink: "https://pmayu.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: 1800000, category: "EWS/LIG/MIG"
  },

  // Rural Development
  {
    sector: "Rural Development",
    schemeName: "Pradhan Mantri Gramin Awaas Yojana (PMGAY)",
    nameHi: "प्रधानमंत्री ग्रामीण आवास योजना (PMGAY)",
    description: "Provides financial assistance for construction of pucca houses with basic amenities to houseless and those living in kutcha houses in rural areas.",
    descriptionHi: "ग्रामीण क्षेत्रों में बेघर और कच्चे मकानों में रहने वालों को बुनियादी सुविधाओं के साथ पक्का मकान बनाने के लिए वित्तीय सहायता प्रदान करती है।",
    eligibility: "Rural households without pucca house. Priority: SC/ST, minorities, landless laborers. BPL families. Women-headed households given priority.",
    eligibilityHi: "पक्का मकान के बिना ग्रामीण परिवार। प्राथमिकता: SC/ST, अल्पसंख्यक, भूमिहीन मजदूर। BPL परिवार। महिला-प्रमुख परिवारों को प्राथमिकता।",
    documents: "Aadhaar Card, BPL Card/Ration Card, Land Ownership Proof, Bank Account, Photograph, MGNREGA Job Card (if applicable)",
    documentsHi: "आधार कार्ड, BPL कार्ड/राशन कार्ड, भूमि स्वामित्व प्रमाण, बैंक खाता, फोटोग्राफ, MGNREGA जॉब कार्ड (यदि लागू हो)",
    benefits: "₹1.20 lakh in plain areas, ₹1.30 lakh in hilly/difficult areas. Additional ₹12,000 for MGNREGA linked unskilled labor. ₹18,000 for toilet construction.",
    benefitsHi: "मैदानी क्षेत्रों में ₹1.20 लाख, पहाड़ी/कठिन क्षेत्रों में ₹1.30 लाख। MGNREGA लिंक्ड अकुशल श्रम के लिए अतिरिक्त ₹12,000। शौचालय निर्माण के लिए ₹18,000।",
    applyLink: "https://pmayg.nic.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "BPL/SC/ST"
  },
  {
    sector: "Rural Development",
    schemeName: "Mahatma Gandhi National Rural Employment Guarantee Act (MGNREGA)",
    nameHi: "महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी अधिनियम (MGNREGA)",
    description: "Guarantees 100 days of wage employment per rural household per year for unskilled manual work, enhancing livelihood security.",
    descriptionHi: "अकुशल मैनुअल काम के लिए प्रति ग्रामीण परिवार प्रतिवर्ष 100 दिनों का मजदूरी रोजगार की गारंटी देता है, जीविका सुरक्षा को बढ़ाता है।",
    eligibility: "Adult members (18+ years) of any rural household. Must be a resident of the rural area. Willing to do unskilled manual work.",
    eligibilityHi: "किसी भी ग्रामीण परिवार के वयस्क सदस्य (18+ वर्ष)। ग्रामीण क्षेत्र का निवासी होना चाहिए। अकुशल मैनुअल काम करने को तैयार।",
    documents: "Aadhaar Card, Bank Account/Post Office Account, Job Card, Mobile Number, Photograph",
    documentsHi: "आधार कार्ड, बैंक खाता/डाकघर खाता, जॉब कार्ड, मोबाइल नंबर, फोटोग्राफ",
    benefits: "100 days guaranteed employment per year. Minimum wage as per state norms. Equal pay for men and women. Work within 5 km radius of residence. Unemployment allowance if work not provided.",
    benefitsHi: "प्रतिवर्ष 100 दिन का गारंटीड रोजगार। राज्य मानदंडों के अनुसार न्यूनतम मजदूरी। पुरुषों और महिलाओं के लिए समान वेतन। निवास से 5 किमी की दूरी के भीतर काम। काम न मिलने पर बेरोजगारी भत्ता।",
    applyLink: "https://nrega.nic.in/",
    ageMin: 18, ageMax: 65, incomeMax: null, category: "All"
  },

  // Water & Sanitation
  {
    sector: "Water & Sanitation",
    schemeName: "Jal Jeevan Mission (JJM)",
    nameHi: "जल जीवन मिशन (JJM)",
    description: "Ensures functional household tap connection to every rural household by 2024, providing safe and adequate drinking water.",
    descriptionHi: "हर ग्रामीण परिवार को 2024 तक कार्यात्मक परिवार नल कनेक्शन सुनिश्चित करता है, सुरक्षित और पर्याप्त पीने का पानी प्रदान करता है।",
    eligibility: "All rural households. Priority to quality-affected areas, aspirational districts, SC/ST majority villages. No income limit.",
    eligibilityHi: "सभी ग्रामीण परिवार। गुणवत्ता प्रभावित क्षेत्रों, आकांक्षी जिलों, SC/ST बहुमत गांवों को प्राथमिकता। कोई आय सीमा नहीं।",
    documents: "Aadhaar Card, Address Proof, Ration Card, Bank Account Details",
    documentsHi: "आधार कार्ड, पता प्रमाण, राशन कार्ड, बैंक खाता विवरण",
    benefits: "Functional household tap connection. 55 liters per capita per day water supply. Safe and clean drinking water. Reduced waterborne diseases.",
    benefitsHi: "कार्यात्मक परिवार नल कनेक्शन। प्रति व्यक्ति प्रतिदिन 55 लीटर पानी की आपूर्ति। सुरक्षित और स्वच्छ पीने का पानी। जलजनित बीमारियों में कमी।",
    applyLink: "https://jjm.gov.in/",
    ageMin: 0, ageMax: null, incomeMax: null, category: "All"
  },
  {
    sector: "Water & Sanitation",
    schemeName: "Swachh Bharat Mission - Gramin (SBM-G)",
    nameHi: "स्वच्छ भारत मिशन - ग्रामीण (SBM-G)",
    description: "Rural sanitation program aiming to achieve universal sanitation coverage, promote cleanliness, and eliminate open defecation.",
    descriptionHi: "सार्वभौमिक स्वच्छता कवरेज हासिल करने, स्वच्छता को बढ़ावा देने और खुले में शौच समाप्त करने का लक्ष्य रखने वाला ग्रामीण स्वच्छता कार्यक्रम।",
    eligibility: "All rural households without toilets. BPL families get full assistance. APL families get partial assistance. All categories.",
    eligibilityHi: "शौचालय के बिना सभी ग्रामीण परिवार। BPL परिवारों को पूरी सहायता। APL परिवारों को आंशिक सहायता। सभी श्रेणियां।",
    documents: "Aadhaar Card, Ration Card, Bank Account, Photograph",
    documentsHi: "आधार कार्ड, राशन कार्ड, बैंक खाता, फोटोग्राफ",
    benefits: "₹12,000 per toilet for construction. Information, Education, and Communication (IEC) activities. Solid and liquid waste management in villages. ODF certification.",
    benefitsHi: "निर्माण के लिए प्रति शौचालय ₹12,000। सूचना, शिक्षा और संचार (IEC) गतिविधियां। गांवों में ठोस और तरल अपशिष्ट प्रबंधन। ODF प्रमाणन।",
    applyLink: "https://sbm.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Energy & Electricity
  {
    sector: "Energy & Electricity",
    schemeName: "Pradhan Mantri Sahaj Bijli Har Ghar Yojana (Saubhagya)",
    nameHi: "प्रधानमंत्री सहज बिजली हर घर योजना (सौभाग्य)",
    description: "Free electricity connection to all unelectrified households in rural and urban areas, promoting universal access to electricity.",
    descriptionHi: "ग्रामीण और शहरी क्षेत्रों में सभी बिजली रहित घरों को मुफ्त बिजली कनेक्शन, बिजली तक सार्वभौमिक पहुंच को बढ़ावा देता है।",
    eligibility: "All unelectrified households. Both rural and urban areas. BPL families get free connections. APL families get subsidized connections.",
    eligibilityHi: "सभी बिजली रहित घर। ग्रामीण और शहरी दोनों क्षेत्र। BPL परिवारों को मुफ्त कनेक्शन। APL परिवारों को अनुदानित कनेक्शन।",
    documents: "Aadhaar Card, Address Proof, Ration Card (for BPL), Photograph",
    documentsHi: "आधार कार्ड, पता प्रमाण, राशन कार्ड (BPL के लिए), फोटोग्राफ",
    benefits: "Free electricity connection to BPL households. LED bulbs, energy efficient fans. No upfront connection charges. Meter installation at no cost.",
    benefitsHi: "BPL घरों को मुफ्त बिजली कनेक्शन। LED बल्ब, ऊर्जा कुशल पंखे। कोई अग्रिम कनेक्शन शुल्क नहीं। बिना लागत मीटर स्थापना।",
    applyLink: "https://saubhagya.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Environment & Sustainability
  {
    sector: "Environment & Sustainability",
    schemeName: "National Mission for a Green India (GIM)",
    nameHi: "हरित भारत के लिए राष्ट्रीय मिशन (GIM)",
    description: "Protecting and restoring India's forest cover, responding to climate change through afforestation, and improving forest-based livelihoods.",
    descriptionHi: "भारत के वन आवरण की सुरक्षा और पुनर्स्थापना, वनीकरण के माध्यम से जलवायु परिवर्तन का जवाब देना और वन-आधारित जीविका में सुधार।",
    eligibility: "Forest-dependent communities. Gram Panchayats. Joint Forest Management Committees. Individuals and groups involved in afforestation.",
    eligibilityHi: "वन-निर्भर समुदाय। ग्राम पंचायतें। संयुक्त वन प्रबंधन समितियां। वनीकरण में शामिल व्यक्ति और समूह।",
    documents: "Aadhaar Card, Address Proof, Land Records (if applicable), Gram Panchayat Resolution",
    documentsHi: "आधार कार्ड, पता प्रमाण, भूमि अभिलेख (यदि लागू हो), ग्राम पंचायत प्रस्ताव",
    benefits: "Afforestation on 5 million hectares. Improved forest-based livelihood. Carbon sequestration benefits. Eco-restoration of degraded ecosystems. Employment generation.",
    benefitsHi: "50 लाख हेक्टेयर पर वनीकरण। वन-आधारित जीविका में सुधार। कार्बन अवशोषण लाभ। गिरे हुए पारिस्थितिक तंत्र का पारिस्थितिक पुनर्स्थापन। रोजगार सृजन।",
    applyLink: "https://moefcc.gov.in/green-india-mission",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Senior Citizens
  {
    sector: "Senior Citizens",
    schemeName: "Pradhan Mantri Vaya Vandana Yojana (PMVVY)",
    nameHi: "प्रधानमंत्री वय वंदना योजना (PMVVY)",
    description: "Pension scheme for senior citizens aged 60+ providing guaranteed monthly pension with Life Insurance Corporation of India.",
    descriptionHi: "60+ आयु के वरिष्ठ नागरिकों के लिए पेंशन योजना जो भारतीय जीवन बीमा निगम के साथ गारंटीड मासिक पेंशन प्रदान करती है।",
    eligibility: "Senior citizens aged 60 years and above. Indian residents. Investment limit up to ₹15 lakh. Available through LIC and designated banks.",
    eligibilityHi: "60 वर्ष और उससे अधिक आयु के वरिष्ठ नागरिक। भारतीय निवासी। ₹15 लाख तक निवेश सीमा। LIC और नामित बैंकों के माध्यम से उपलब्ध।",
    documents: "Aadhaar Card, PAN Card, Bank Account Details, Age Proof, Passport Size Photograph",
    documentsHi: "आधार कार्ड, पैन कार्ड, बैंक खाता विवरण, आयु प्रमाण, पासपोर्ट साइज फोटो",
    benefits: "Guaranteed pension of ₹1,000 per month for ₹1,20,000 investment (10% p.a.). Option for monthly, quarterly, half-yearly, or yearly pension. Loan facility available after 3 years.",
    benefitsHi: "₹1,20,000 निवेश पर ₹1,000 प्रति माह की गारंटीड पेंशन (10% प्रति वर्ष)। मासिक, त्रैमासिक, अर्धवार्षिक या वार्षिक पेंशन का विकल्प। 3 वर्ष बाद ऋण सुविधा उपलब्ध।",
    applyLink: "https://www.licindia.in/",
    ageMin: 60, ageMax: null, incomeMax: null, category: "All"
  },

  // Divyang (Disability Support)
  {
    sector: "Divyang (Disability Support)",
    schemeName: "Deendayal Disabled Rehabilitation Scheme (DDRS)",
    nameHi: "दीनदयाल विकलांग पुनर्वास योजना (DDRS)",
    description: "Creates an enabling environment for persons with disabilities through rehabilitation, skill development, and providing assistive devices.",
    descriptionHi: "पुनर्वास, कौशल विकास और सहायक उपकरणों के माध्यम से विकलांग व्यक्तियों के लिए एक सक्षम वातावरण बनाता है।",
    eligibility: "Persons with Disabilities (PwD) with 40% or more disability. All categories. No income limit (but priority for BPL). Age no bar.",
    eligibilityHi: "40% या अधिक विकलांगता वाले विकलांग व्यक्ति (PwD)। सभी श्रेणियां। कोई आय सीमा नहीं (लेकिन BPL को प्राथमिकता)। आयु नहीं।",
    documents: "Disability Certificate, Aadhaar Card, Income Certificate, Bank Account, Photograph",
    documentsHi: "विकलांगता प्रमाण पत्र, आधार कार्ड, आय प्रमाण पत्र, बैंक खाता, फोटोग्राफ",
    benefits: "Rehabilitation services. Skill development training. Assistive devices (wheelchairs, hearing aids, etc.). Educational support. Employment facilitation.",
    benefitsHi: "पुनर्वास सेवाएं। कौशल विकास प्रशिक्षण। सहायक उपकरण (व्हीलचेयर, श्रवण यंत्र, आदि)। शैक्षिक सहायता। रोजगार सुविधा।",
    applyLink: "https://disabilityaffairs.gov.in/",
    ageMin: 0, ageMax: null, incomeMax: null, category: "All"
  },

  // Social Welfare & Poverty
  {
    sector: "Social Welfare & Poverty",
    schemeName: "National Social Assistance Programme (NSAP)",
    nameHi: "राष्ट्रीय सामाजिक सहायता कार्यक्रम (NSAP)",
    description: "Central sector scheme providing social pension and financial assistance to elderly, widows, and persons with disabilities from BPL families.",
    descriptionHi: "BPL परिवारों से बुजुर्गों, विधवाओं और विकलांग व्यक्तियों को सामाजिक पेंशन और वित्तीय सहायता प्रदान करने वाला केंद्रीय क्षेत्र योजना।",
    eligibility: "BPL families. Elderly (60+ years), widows (40+ years), persons with disabilities (40%+ disability). No other pension or similar benefit.",
    eligibilityHi: "BPL परिवार। वृद्ध (60+ वर्ष), विधवा (40+ वर्ष), विकलांग व्यक्ति (40%+ विकलांगता)। कोई अन्य पेंशन या इसी तरह का लाभ नहीं।",
    documents: "Aadhaar Card, BPL Card/Ration Card, Age Proof, Disability Certificate, Death Certificate of husband (for widows), Bank Account",
    documentsHi: "आधार कार्ड, BPL कार्ड/राशन कार्ड, आयु प्रमाण, विकलांगता प्रमाण पत्र, पति का मृत्यु प्रमाण पत्र (विधवाओं के लिए), बैंक खाता",
    benefits: "Old Age Pension: ₹200-₹500 per month. Widow Pension: ₹200-₹500 per month. Disability Pension: ₹200-₹500 per month. Additional state top-ups available.",
    benefitsHi: "वृद्धावस्था पेंशन: ₹200-₹500 प्रति माह। विधवा पेंशन: ₹200-₹500 प्रति माह। विकलांगता पेंशन: ₹200-₹500 प्रति माह। अतिरिक्त राज्य टॉप-अप उपलब्ध।",
    applyLink: "https://nsap.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "BPL"
  },

  // Defence & Ex-Servicemen
  {
    sector: "Defence & Ex-Servicemen",
    schemeName: "Ex-Servicemen Contributory Health Scheme (ECHS)",
    nameHi: "भूतपूर्व सैनिक अंशदाय स्वास्थ्य योजना (ECHS)",
    description: "Comprehensive healthcare scheme for ex-servicemen and their dependents providing outpatient and inpatient treatment through empaneled hospitals.",
    descriptionHi: "भूतपूर्व सैनिकों और उनके आश्रितों के लिए व्यापक स्वास्थ्य सेवा योजना जो अनुबंधित अस्पतालों के माध्यम से बाह्य रोगी और भर्ती उपचार प्रदान करती है।",
    eligibility: "Ex-servicemen (retired from Army, Navy, Air Force). Their dependents (spouse, children). Widows of ex-servicemen. Must have ECHS card.",
    eligibilityHi: "भूतपूर्व सैनिक (सेना, नौसेना, वायु सेना से सेवानिवृत्त)। उनके आश्रित (पति/पत्नी, बच्चे)। भूतपूर्व सैनिकों की विधवाएं। ECHS कार्ड होना चाहिए।",
    documents: "Discharge Certificate, PPO, Aadhaar Card, ECHS Card, Bank Account Details, Photograph",
    documentsHi: "छुट्टी प्रमाण पत्र, PPO, आधार कार्ड, ECHS कार्ड, बैंक खाता विवरण, फोटोग्राफ",
    benefits: "Free OPD treatment at ECHS polyclinics. Hospitalization at empaneled hospitals. Referral to government hospitals. Free medicines and diagnostics.",
    benefitsHi: "ECHS बहुउद्देशीय क्लीनिकों पर मुफ्त OPD उपचार। अनुबंधित अस्पतालों में भर्ती। सरकारी अस्पतालों को रेफरल। मुफ्त दवाइयां और डायग्नोस्टिक्स।",
    applyLink: "https://echs.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Transport & Infrastructure
  {
    sector: "Transport & Infrastructure",
    schemeName: "PM Gati Shakti National Master Plan",
    nameHi: "पीएम गति शक्ति राष्ट्रीय मास्टर प्लान",
    description: "Digital platform for integrated planning and coordinated implementation of infrastructure connectivity projects across all modes of transport.",
    descriptionHi: "परिवहन के सभी मोड में बुनियादी ढांचा कनेक्टिविटी परियोजनाओं की एकीकृत योजना और समन्वित कार्यान्वयन के लिए डिजिटल प्लेटफॉर्म।",
    eligibility: "State and Central Government departments. Infrastructure development agencies. Logistics companies seeking route planning.",
    eligibilityHi: "राज्य और केंद्रीय सरकार विभाग। बुनियादी ढांचा विकास एजेंसियां। मार्ग योजना चाहने वाली लॉजिस्टिक कंपनियां।",
    documents: "Project Proposal, Land Acquisition Documents, Environmental Clearance, Feasibility Report",
    documentsHi: "परियोजना प्रस्ताव, भूमि अधिग्रहण दस्तावेज, पर्यावरण मंजूरी, संभाव्यता रिपोर्ट",
    benefits: "Integrated infrastructure planning. Reduced logistics costs. Faster project implementation. Multi-modal connectivity. Real-time project monitoring.",
    benefitsHi: "एकीकृत बुनियादी ढांचा योजना। कम लॉजिस्टिक लागत। तेज परियोजना कार्यान्वयन। बहु-मोडल कनेक्टिविटी। रीयल-टाइम परियोजना निगरानी।",
    applyLink: "https://gatishakti.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Digital & Technology
  {
    sector: "Digital & Technology",
    schemeName: "Digital India Programme",
    nameHi: "डिजिटल इंडिया प्रोग्राम",
    description: "Transforms India into a digitally empowered society by improving digital infrastructure, digital literacy, and delivering government services electronically.",
    descriptionHi: "डिजिटल बुनियादी ढांचा, डिजिटल साक्षरता में सुधार और सरकारी सेवाओं को इलेक्ट्रॉनिक रूप से वितरित करके भारत को डिजिटल रूप से सशक्त समाज में बदलता है।",
    eligibility: "All Indian citizens. Special focus on rural areas and digital literacy for underprivileged communities. Students, farmers, and government employees.",
    eligibilityHi: "सभी भारतीय नागरिक। ग्रामीण क्षेत्रों और वंचित समुदायों के लिए डिजिटल साक्षरता पर विशेष ध्यान। छात्र, किसान और सरकारी कर्मचारी।",
    documents: "Aadhaar Card, Mobile Number, Email ID (optional), Address Proof",
    documentsHi: "आधार कार्ड, मोबाइल नंबर, ईमेल आईडी (वैकल्पिक), पता प्रमाण",
    benefits: "Common Service Centers (CSCs) for digital services. DigiLocker for document storage. UMANG app for government services. Digital payment facilitation. Free Wi-Fi in public places.",
    benefitsHi: "डिजिटल सेवाओं के लिए सामान्य सेवा केंद्र (CSCs)। दस्तावेज भंडारण के लिए DigiLocker। सरकारी सेवाओं के लिए UMANG ऐप। डिजिटल भुगतान सुविधा। सार्वजनिक स्थानों पर मुफ्त वाईफाई।",
    applyLink: "https://www.digitalindia.gov.in/",
    ageMin: 0, ageMax: null, incomeMax: null, category: "All"
  },
  {
    sector: "Digital & Technology",
    schemeName: "Pradhan Mantri Gramin Digital Saksharta Abhiyan (PMGDISHA)",
    nameHi: "प्रधानमंत्री ग्रामीण डिजिटल साक्षरता अभियान (PMGDISHA)",
    description: "Digital literacy program to make 6 crore rural households digitally literate by training at least one member per household.",
    descriptionHi: "प्रति परिवार कम से कम एक सदस्य को प्रशिक्षित करके 6 करोड़ ग्रामीण परिवारों को डिजिटल रूप से साक्षर बनाने का कार्यक्रम।",
    eligibility: "Rural households. At least one member aged 14-60 years. Should not have completed digital literacy training before. Priority to BPL and women.",
    eligibilityHi: "ग्रामीण परिवार। कम से कम एक सदस्य 14-60 वर्ष की आयु का। पहले डिजिटल साक्षरता प्रशिक्षण पूरा नहीं किया हो। BPL और महिलाओं को प्राथमिकता।",
    documents: "Aadhaar Card, Ration Card, Photograph",
    documentsHi: "आधार कार्ड, राशन कार्ड, फोटोग्राफ",
    benefits: "Free digital literacy training. Training on operating digital devices, internet usage, digital payments, government services. Certificate upon completion.",
    benefitsHi: "मुफ्त डिजिटल साक्षरता प्रशिक्षण। डिजिटल उपकरणों का संचालन, इंटरनेट उपयोग, डिजिटल भुगतान, सरकारी सेवाओं पर प्रशिक्षण। पूर्ण होने पर प्रमाण पत्र।",
    applyLink: "https://pmgdisha.gov.in/",
    ageMin: 14, ageMax: 60, incomeMax: null, category: "All"
  },

  // Food & Nutrition
  {
    sector: "Food & Nutrition",
    schemeName: "National Food Security Act (NFSA) - Public Distribution System",
    nameHi: "राष्ट्रीय खाद्य सुरक्षा अधिनियम (NFSA) - सार्वजनिक वितरण प्रणाली",
    description: "Provides subsidized food grains (rice, wheat, coarse grains) to eligible households through the Public Distribution System.",
    descriptionHi: "सार्वजनिक वितरण प्रणाली के माध्यम से पात्र परिवारों को अनुदानित खाद्यान्न (चावल, गेहूं, मोटे अनाज) प्रदान करता है।",
    eligibility: "Priority Households (PHH) and Antyodaya Anna Yojana (AAY) families. BPL families. Covers approximately 67% of India's population.",
    eligibilityHi: "प्राथमिकता परिवार (PHH) और अंत्योदय अन्न योजना (AAY) परिवार। BPL परिवार। भारत की लगभग 67% आबादी को कवर करता है।",
    documents: "Aadhaar Card, Ration Card, Bank Account Details, Address Proof, Photograph",
    documentsHi: "आधार कार्ड, राशन कार्ड, बैंक खाता विवरण, पता प्रमाण, फोटोग्राफ",
    benefits: "5 kg food grains per person per month. Rice at ₹3/kg, Wheat at ₹2/kg, Coarse grains at ₹1/kg. AAY: 35 kg per family per month. Meal and maternity benefits.",
    benefitsHi: "प्रति व्यक्ति प्रति माह 5 किलो खाद्यान्न। चावल ₹3/किग्रा, गेहूं ₹2/किग्रा, मोटे अनाज ₹1/किग्रा। AAY: प्रति परिवार प्रति माह 35 किग्रा। भोजन और प्रसूति लाभ।",
    applyLink: "https://nfsa.gov.in/",
    ageMin: 0, ageMax: null, incomeMax: null, category: "BPL/AAY"
  },
  {
    sector: "Food & Nutrition",
    schemeName: "Pradhan Mantri Garib Kalyan Anna Yojana (PMGKAY)",
    nameHi: "प्रधानमंत्री गरीब कल्याण अन्न योजना (PMGKAY)",
    description: "Free food grains distribution scheme providing additional food security to the poorest during economic distress periods.",
    descriptionHi: "मुफ्त खाद्यान्न वितरण योजना जो आर्थिक संकट के दौरान सबसे गरीबों को अतिरिक्त खाद्य सुरक्षा प्रदान करती है।",
    eligibility: "All NFSA beneficiaries (PHH and AAY cardholders). No additional eligibility criteria beyond existing NFSA ration cards.",
    eligibilityHi: "सभी NFSA लाभार्थी (PHH और AAY कार्डधारक)। मौजूदा NFSA राशन कार्डों से परे कोई अतिरिक्त पात्रता मानदंड नहीं।",
    documents: "NFSA Ration Card, Aadhaar Card",
    documentsHi: "NFSA राशन कार्ड, आधार कार्ड",
    benefits: "Free 5 kg food grains per person per month. Wheat and rice. In addition to regular NFSA allocation. Distributed through Fair Price Shops.",
    benefitsHi: "प्रति व्यक्ति प्रति माह मुफ्त 5 किलो खाद्यान्न। गेहूं और चावल। नियमित NFSA आवंटन के अतिरिक्त। उचित मूल्य की दुकानों के माध्यम से वितरित।",
    applyLink: "https://dfpd.gov.in/pmgkay",
    ageMin: 0, ageMax: null, incomeMax: null, category: "BPL/AAY"
  },

  // Industry & Manufacturing
  {
    sector: "Industry & Manufacturing",
    schemeName: "Production Linked Incentive (PLI) Scheme",
    nameHi: "उत्पादन से जुड़ी प्रोत्साहन (PLI) योजना",
    description: "Incentive scheme to boost domestic manufacturing in key sectors and make Indian companies globally competitive through performance-linked incentives.",
    descriptionHi: "प्रमुख क्षेत्रों में घरेलू विनिर्माण को बढ़ावा देने और प्रदर्शन-लिंक्ड प्रोत्साहन के माध्यम से भारतीय कंपनियों को वैश्विक रूप से प्रतिस्पर्धी बनाने की योजना।",
    eligibility: "Companies engaged in manufacturing in identified sectors (electronics, pharma, auto, textiles, etc.). Minimum investment thresholds apply. Both domestic and foreign companies.",
    eligibilityHi: "पहचाने गए क्षेत्रों (इलेक्ट्रॉनिक्स, फार्मा, ऑटो, टेक्सटाइल, आदि) में विनिर्माण में लगी कंपनियां। न्यूनतम निवेश सीमा लागू होती है। घरेलू और विदेशी दोनों कंपनियां।",
    documents: "Company Registration Certificate, GST Registration, PAN Card, Bank Account, Investment Proposal, Manufacturing Plan",
    documentsHi: "कंपनी पंजीकरण प्रमाण पत्र, GST पंजीकरण, पैन कार्ड, बैंक खाता, निवेश प्रस्ताव, विनिर्माण योजना",
    benefits: "4-6% incentive on incremental sales for 5 years. Total outlay of ₹1.97 lakh crore across sectors. Promotes 'Make in India'. Employment generation.",
    benefitsHi: "5 वर्षों के लिए वृद्धिशील बिक्री पर 4-6% प्रोत्साहन। सभी क्षेत्रों में कुल ₹1.97 लाख करोड़ का व्यय। 'मेक इन इंडिया' को बढ़ावा। रोजगार सृजन।",
    applyLink: "https://pli.gov.in/",
    ageMin: 18, ageMax: null, incomeMax: null, category: "All"
  },

  // Allied Rural Livelihood
  {
    sector: "Allied Rural Livelihood",
    schemeName: "Deendayal Antyodaya Yojana - National Rural Livelihoods Mission (DAY-NRLM)",
    nameHi: "दीनदयाल अंत्योदय योजना - राष्ट्रीय ग्रामीण आजीविका मिशन (DAY-NRLM)",
    description: "Poverty alleviation program promoting self-employment and organization of rural poor into Self Help Groups (SHGs) for sustainable livelihood opportunities.",
    descriptionHi: "स्व-रोजगार को बढ़ावा देने और ग्रामीण गरीबों को सतत आजीविका अवसरों के लिए स्वयं सहायता समूहों (SHGs) में संगठित करने वाला गरीबी उन्मूलन कार्यक्रम।",
    eligibility: "Rural poor households. BPL families. Women's Self Help Groups. Landless laborers. Artisans and small farmers.",
    eligibilityHi: "ग्रामीण गरीब परिवार। BPL परिवार। महिला स्वयं सहायता समूह। भूमिहीन मजदूर। कारीगर और छोटे किसान।",
    documents: "Aadhaar Card, BPL Card, Bank Account Details, SHG Registration, Address Proof, Photograph",
    documentsHi: "आधार कार्ड, BPL कार्ड, बैंक खाता विवरण, SHG पंजीकरण, पता प्रमाण, फोटोग्राफ",
    benefits: "Revolving fund of ₹10,000-₹15,000 per SHG. Community Investment Fund up to ₹10 lakh. Bank linkage for loans. Skill training and marketing support. Interest subvention on loans.",
    benefitsHi: "प्रति SHG ₹10,000-₹15,000 का चक्रवातीय कोष। ₹10 लाख तक सामुदायिक निवेश कोष। ऋण के लिए बैंक लिंकेज। कौशल प्रशिक्षण और विपणन सहायता। ऋण पर ब्याज अनुदान।",
    applyLink: "https://nrlm.gov.in/",
    ageMin: 18, ageMax: 60, incomeMax: null, category: "BPL"
  },
  {
    sector: "Allied Rural Livelihood",
    schemeName: "Kisan Credit Card (KCC) Scheme",
    nameHi: "किसान क्रेडिट कार्ड (KCC) योजना",
    description: "Provides affordable credit to farmers for agricultural needs, post-harvest expenses, and consumption requirements at subsidized interest rates.",
    descriptionHi: "किसानों को कृषि आवश्यकताओं, फसल कटाई के बाद के खर्चों और उपभोग आवश्यकताओं के लिए अनुदानित ब्याज दरों पर किफायती ऋण प्रदान करता है।",
    eligibility: "Farmers (individual/Joint). Sharecroppers, tenants, oral lessees. Farmers engaged in animal husbandry, fisheries. All categories.",
    eligibilityHi: "किसान (व्यक्तिगत/संयुक्त)। बंटई, किरायेदार, मौखिक पट्टेदार। पशुपालन, मत्स्य पालन में लगे किसान। सभी श्रेणियां।",
    documents: "Aadhaar Card, Land Records, Bank Account Details, Photograph, Farm Details",
    documentsHi: "आधार कार्ड, भूमि अभिलेख, बैंक खाता विवरण, फोटोग्राफ, खेत विवरण",
    benefits: "Credit limit up to ₹3 lakh. Interest subvention of 2% on regular repayment. Additional 3% for timely repayment. Covers crop production, animal husbandry, and fishery.",
    benefitsHi: "₹3 लाख तक की ऋण सीमा। नियमित चुकौती पर 2% ब्याज अनुदान। समय पर चुकौती पर अतिरिक्त 3%। फसल उत्पादन, पशुपालन और मत्स्य पालन को कवर करता है।",
    applyLink: "https://www.pmkisan.gov.in/KCC",
    ageMin: 18, ageMax: 65, incomeMax: null, category: "All"
  }
]

async function main() {
  console.log('Seeding schemes...')
  
  for (const scheme of schemes) {
    await prisma.scheme.create({
      data: scheme
    })
    console.log(`  ✓ ${scheme.schemeName}`)
  }
  
  console.log(`\n✅ Successfully seeded ${schemes.length} schemes`)
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
