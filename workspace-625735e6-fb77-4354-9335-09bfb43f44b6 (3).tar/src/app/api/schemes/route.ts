import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const sector = searchParams.get('sector')
    const search = searchParams.get('search')
    const age = searchParams.get('age')
    const category = searchParams.get('category')

    const where: Record<string, unknown> = {}

    if (sector && sector !== 'All') {
      where.sector = sector
    }

    if (search && search.trim()) {
      where.OR = [
        { schemeName: { contains: search.trim() } },
        { description: { contains: search.trim() } },
        { nameHi: { contains: search.trim() } },
        { descriptionHi: { contains: search.trim() } },
      ]
    }

    if (age) {
      const ageNum = parseInt(age)
      where.OR = [
        ...(where.OR || []),
        { ageMin: { lte: ageNum } },
        { ageMin: null },
      ]
    }

    if (category && category !== 'All') {
      where.category = category
    }

    const schemes = await db.scheme.findMany({
      where,
      orderBy: { sector: 'asc' },
    })

    return NextResponse.json(schemes)
  } catch (error) {
    console.error('Error fetching schemes:', error)
    return NextResponse.json({ error: 'Failed to fetch schemes' }, { status: 500 })
  }
}
