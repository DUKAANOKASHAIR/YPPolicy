import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { logUserNotification } from '@/lib/notify'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, address, phone } = body

    if (!name?.trim()) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 })
    }
    if (!address?.trim()) {
      return NextResponse.json({ error: 'Address is required' }, { status: 400 })
    }
    if (!phone?.trim() || phone.trim().length < 10) {
      return NextResponse.json({ error: 'Valid phone number is required' }, { status: 400 })
    }

    const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10)

    // Check if phone already registered
    const existing = await db.user.findUnique({ where: { phone: cleanPhone } })
    if (existing) {
      return NextResponse.json({ error: 'This phone number is already registered. Please sign in.' }, { status: 409 })
    }

    const user = await db.user.create({
      data: {
        name: name.trim(),
        address: address.trim(),
        phone: cleanPhone,
      },
    })

    // Log notification for youthpolite@gmail.com
    await logUserNotification({
      name: user.name,
      phone: user.phone,
      address: user.address,
      action: 'register',
    })

    return NextResponse.json({
      success: true,
      user: { id: user.id, name: user.name, phone: user.phone },
      message: 'Registration successful! Welcome aboard.',
    }, { status: 201 })
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json({ error: 'Registration failed' }, { status: 500 })
  }
}
