import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { logUserNotification } from '@/lib/notify'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone } = body

    if (!phone?.trim() || phone.trim().length < 10) {
      return NextResponse.json({ error: 'Valid phone number is required' }, { status: 400 })
    }

    const cleanPhone = phone.trim().replace(/\D/g, '').slice(-10)

    const user = await db.user.findUnique({ where: { phone: cleanPhone } })

    if (!user) {
      return NextResponse.json({ error: 'Phone number not found. Please register first.' }, { status: 404 })
    }

    // Log sign-in notification
    await logUserNotification({
      name: user.name,
      phone: user.phone,
      address: user.address,
      action: 'signin',
    })

    return NextResponse.json({
      success: true,
      user: { id: user.id, name: user.name, phone: user.phone, address: user.address },
      message: `Welcome back, ${user.name}!`,
    })
  } catch (error) {
    console.error('Sign-in error:', error)
    return NextResponse.json({ error: 'Sign-in failed' }, { status: 500 })
  }
}
