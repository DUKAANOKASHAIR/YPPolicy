import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { verifyAdminToken } from '@/lib/admin-auth'

export async function GET(request: NextRequest) {
  if (!verifyAdminToken(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const searchParams = request.nextUrl.searchParams
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')
    const search = searchParams.get('search') || ''
    const sector = searchParams.get('sector') || ''

    const where: Record<string, unknown> = {}

    if (search.trim()) {
      where.OR = [
        { schemeName: { contains: search.trim() } },
        { nameHi: { contains: search.trim() } },
        { description: { contains: search.trim() } },
      ]
    }

    if (sector && sector !== 'All') {
      where.sector = sector
    }

    const [schemes, total] = await Promise.all([
      db.scheme.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.scheme.count({ where }),
    ])

    return NextResponse.json({ schemes, total, page, limit })
  } catch (error) {
    console.error('Error fetching admin schemes:', error)
    return NextResponse.json(
      { error: 'Failed to fetch schemes' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  if (!verifyAdminToken(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await request.json()

    const {
      sector,
      schemeName,
      nameHi,
      description,
      descriptionHi,
      eligibility,
      eligibilityHi,
      documents,
      documentsHi,
      benefits,
      benefitsHi,
      applyLink,
      ageMin,
      ageMax,
      incomeMax,
      category,
    } = body

    // Validate required fields
    if (!schemeName?.trim()) {
      return NextResponse.json({ error: 'Scheme name is required' }, { status: 400 })
    }
    if (!sector?.trim()) {
      return NextResponse.json({ error: 'Sector is required' }, { status: 400 })
    }
    if (!description?.trim()) {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 })
    }
    if (!eligibility?.trim()) {
      return NextResponse.json({ error: 'Eligibility is required' }, { status: 400 })
    }
    if (!benefits?.trim()) {
      return NextResponse.json({ error: 'Benefits are required' }, { status: 400 })
    }
    if (!applyLink?.trim()) {
      return NextResponse.json({ error: 'Apply link is required' }, { status: 400 })
    }

    const scheme = await db.scheme.create({
      data: {
        sector: sector.trim(),
        schemeName: schemeName.trim(),
        nameHi: nameHi?.trim() || schemeName.trim(),
        description: description.trim(),
        descriptionHi: descriptionHi?.trim() || description.trim(),
        eligibility: eligibility.trim(),
        eligibilityHi: eligibilityHi?.trim() || eligibility.trim(),
        documents: documents?.trim() || '',
        documentsHi: documentsHi?.trim() || documents?.trim() || '',
        benefits: benefits.trim(),
        benefitsHi: benefitsHi?.trim() || benefits.trim(),
        applyLink: applyLink.trim(),
        ageMin: ageMin ? parseInt(ageMin) : null,
        ageMax: ageMax ? parseInt(ageMax) : null,
        incomeMax: incomeMax ? parseInt(incomeMax) : null,
        category: category?.trim() || 'All',
      },
    })

    return NextResponse.json({ scheme, success: true }, { status: 201 })
  } catch (error) {
    console.error('Error creating scheme:', error)
    return NextResponse.json(
      { error: 'Failed to create scheme' },
      { status: 500 }
    )
  }
}
