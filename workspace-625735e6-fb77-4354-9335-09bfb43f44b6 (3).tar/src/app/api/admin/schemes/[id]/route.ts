import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { verifyAdminToken } from '@/lib/admin-auth'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!verifyAdminToken(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await params
    const scheme = await db.scheme.findUnique({ where: { id } })

    if (!scheme) {
      return NextResponse.json({ error: 'Scheme not found' }, { status: 404 })
    }

    return NextResponse.json({ scheme })
  } catch (error) {
    console.error('Error fetching scheme:', error)
    return NextResponse.json({ error: 'Failed to fetch scheme' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!verifyAdminToken(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await params
    const body = await request.json()

    // Check if scheme exists
    const existing = await db.scheme.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Scheme not found' }, { status: 404 })
    }

    const {
      sector,
      schemeName,
      nameHi,
      description,
      descriptionHi,
      eligibility,
      eligibilityHi,
      documents,
      documentsHi,
      benefits,
      benefitsHi,
      applyLink,
      ageMin,
      ageMax,
      incomeMax,
      category,
    } = body

    // Validate required fields
    if (!schemeName?.trim()) {
      return NextResponse.json({ error: 'Scheme name is required' }, { status: 400 })
    }
    if (!sector?.trim()) {
      return NextResponse.json({ error: 'Sector is required' }, { status: 400 })
    }
    if (!description?.trim()) {
      return NextResponse.json({ error: 'Description is required' }, { status: 400 })
    }
    if (!eligibility?.trim()) {
      return NextResponse.json({ error: 'Eligibility is required' }, { status: 400 })
    }
    if (!benefits?.trim()) {
      return NextResponse.json({ error: 'Benefits are required' }, { status: 400 })
    }
    if (!applyLink?.trim()) {
      return NextResponse.json({ error: 'Apply link is required' }, { status: 400 })
    }

    const scheme = await db.scheme.update({
      where: { id },
      data: {
        sector: sector.trim(),
        schemeName: schemeName.trim(),
        nameHi: nameHi?.trim() || schemeName.trim(),
        description: description.trim(),
        descriptionHi: descriptionHi?.trim() || description.trim(),
        eligibility: eligibility.trim(),
        eligibilityHi: eligibilityHi?.trim() || eligibility.trim(),
        documents: documents?.trim() || '',
        documentsHi: documentsHi?.trim() || documents?.trim() || '',
        benefits: benefits.trim(),
        benefitsHi: benefitsHi?.trim() || benefits.trim(),
        applyLink: applyLink.trim(),
        ageMin: ageMin ? parseInt(ageMin) : null,
        ageMax: ageMax ? parseInt(ageMax) : null,
        incomeMax: incomeMax ? parseInt(incomeMax) : null,
        category: category?.trim() || 'All',
      },
    })

    return NextResponse.json({ scheme, success: true })
  } catch (error) {
    console.error('Error updating scheme:', error)
    return NextResponse.json({ error: 'Failed to update scheme' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!verifyAdminToken(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await params
    const existing = await db.scheme.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'Scheme not found' }, { status: 404 })
    }

    await db.scheme.delete({ where: { id } })

    return NextResponse.json({ success: true, message: 'Scheme deleted successfully' })
  } catch (error) {
    console.error('Error deleting scheme:', error)
    return NextResponse.json({ error: 'Failed to delete scheme' }, { status: 500 })
  }
}
