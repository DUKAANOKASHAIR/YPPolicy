import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Youth Polite for Policy - Discover Government Schemes",
  description: "Easily discover, understand, and apply for Indian government schemes based on different sectors. Making government schemes accessible for every citizen.",
  keywords: ["government schemes", "India", "youth", "policy", "PM schemes", " Sarkari Yojana"],
  authors: [{ name: "Youth Polite for Policy" }],
  openGraph: {
    title: "Youth Polite for Policy",
    description: "Discover Indian Government Schemes for You",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
