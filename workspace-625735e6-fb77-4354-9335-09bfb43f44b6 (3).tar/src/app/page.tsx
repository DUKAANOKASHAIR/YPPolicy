'use client'

import React, { useEffect, useState, useMemo, useCallback } from 'react'
import { useAppStore } from '@/store/useAppStore'
import { t } from '@/lib/translations'
import { sectors, getSectorName, getSectorConfig, sectorKeyMap } from '@/lib/sectors'
import { DynamicIcon } from '@/components/DynamicIcon'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { AdminLoginScreen, AdminDashboard, AdminAddSchemeScreen, AdminEditSchemeScreen } from '@/components/AdminScreens'
import { RegisterScreen, SigninScreen, AdminUsersTab } from '@/components/UserScreens'

interface Scheme {
  id: string
  sector: string
  schemeName: string
  nameHi: string
  description: string
  descriptionHi: string
  eligibility: string
  eligibilityHi: string
  documents: string
  documentsHi: string
  benefits: string
  benefitsHi: string
  applyLink: string
  ageMin: number | null
  ageMax: number | null
  incomeMax: number | null
  category: string
}

// ============ HEADER ============
function AdminHeader() {
  const { screen, goBack, adminEmail } = useAppStore()
  const isAdminScreen = screen === 'adminDashboard' || screen === 'adminAddScheme' || screen === 'adminEditScheme'
  const showBack = screen !== 'adminDashboard' && screen !== 'adminLogin'

  if (!isAdminScreen) return null

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {showBack && (
            <button
              onClick={goBack}
              className="p-1.5 -ml-1.5 rounded-full hover:bg-gray-100 transition-colors"
              aria-label="Back"
            >
              <ChevronLeftIcon size={22} />
            </button>
          )}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-slate-700 to-slate-800 rounded-lg flex items-center justify-center shadow-md">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              </svg>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-sm font-bold text-gray-900 leading-tight">Admin Panel</h1>
              <p className="text-[10px] text-gray-500 leading-tight">Scheme Management</p>
            </div>
          </div>
        </div>
        {adminEmail && (
          <span className="text-xs text-gray-500 hidden sm:block">{adminEmail}</span>
        )}
      </div>
    </header>
  )
}

function Header() {
  const { screen, toggleLanguage, language, goBack, goHome, bookmarks, adminToken, setScreen, currentUser, signOutUser } = useAppStore()
  const showBack = screen !== 'home'
  const isAdminScreen = screen === 'adminLogin' || screen === 'adminDashboard' || screen === 'adminAddScheme' || screen === 'adminEditScheme'
  const isAuthScreen = screen === 'register' || screen === 'signin'

  if (isAdminScreen || isAuthScreen) return null

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {showBack && (
            <button
              onClick={goBack}
              className="p-1.5 -ml-1.5 rounded-full hover:bg-gray-100 transition-colors"
              aria-label={t('back', language)}
            >
              <ChevronLeftIcon size={22} />
            </button>
          )}
          <button onClick={goHome} className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center shadow-md">
              <span className="text-white font-bold text-sm">YP</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-sm font-bold text-gray-900 leading-tight">
                {language === 'hi' ? 'यूथ पोलाइट फॉर पॉलिसी' : 'Youth Polite for Policy'}
              </h1>
              <p className="text-[10px] text-gray-500 leading-tight">
                {t('appSubtitle', language)}
              </p>
            </div>
          </button>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => useAppStore.getState().setScreen('bookmarks')}
            className={`p-2 rounded-full hover:bg-gray-100 transition-colors relative ${screen === 'bookmarks' ? 'bg-orange-50 text-orange-600' : 'text-gray-600'}`}
            aria-label={t('bookmarks', language)}
          >
            <BookmarkIcon size={20} />
            {bookmarks.length > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4.5 h-4.5 bg-orange-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                {bookmarks.length}
              </span>
            )}
          </button>
          <button
            onClick={toggleLanguage}
            className="px-3 py-1.5 text-xs font-medium rounded-full border border-gray-200 hover:bg-gray-50 transition-colors text-gray-700 flex items-center gap-1"
            aria-label="Toggle language"
          >
            <GlobeIcon size={14} />
            {t('language', language)}
          </button>
          <button
            onClick={() => adminToken ? useAppStore.getState().goToAdminDashboard() : setScreen('adminLogin')}
            className={`p-2 rounded-full hover:bg-gray-100 transition-colors ${adminToken ? 'text-green-600' : 'text-gray-600'}`}
            aria-label="Admin"
            title={adminToken ? 'Admin Dashboard' : 'Admin Login'}
          >
            <svg width={20} height={20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
          </button>
          {currentUser ? (
            <div className="flex items-center gap-1.5">
              <span className="hidden sm:inline text-xs font-medium text-gray-600 max-w-[100px] truncate">{currentUser.name}</span>
              <button
                onClick={signOutUser}
                className="p-2 rounded-full hover:bg-red-50 transition-colors text-gray-400 hover:text-red-500"
                aria-label="Sign Out"
                title="Sign Out"
              >
                <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
              </button>
            </div>
          ) : (
            <button
              onClick={() => setScreen('register')}
              className="px-3 py-1.5 text-xs font-medium rounded-full bg-orange-500 hover:bg-orange-600 text-white shadow-sm transition-colors"
            >
              Register
            </button>
          )}
        </div>
      </div>
    </header>
  )
}

function ChevronLeftIcon({ size, className }: { size: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="m15 18-6-6 6-6"/>
    </svg>
  )
}

function BookmarkIcon({ size, className }: { size: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
    </svg>
  )
}

function GlobeIcon({ size, className }: { size: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>
    </svg>
  )
}

// ============ SEARCH BAR ============
function SearchBar({ value, onChange, onFilterClick }: { value: string; onChange: (v: string) => void; onFilterClick: () => void }) {
  const language = useAppStore(s => s.language)
  return (
    <div className="flex gap-2">
      <div className="relative flex-1">
        <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
        </svg>
        <Input
          placeholder={t('searchPlaceholder', language)}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="pl-10 h-11 rounded-xl border-gray-200 bg-gray-50/50 text-base focus:bg-white"
        />
        {value && (
          <button
            onClick={() => onChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 6 6 18"/><path d="m6 6 12 12"/>
            </svg>
          </button>
        )}
      </div>
      <Dialog>
        <DialogTrigger asChild>
          <Button
            variant="outline"
            className="h-11 px-3 rounded-xl border-gray-200"
            onClick={onFilterClick}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-500">
              <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
            </svg>
            <span className="sm:inline hidden text-gray-600 text-sm ml-1.5">{t('filters', language)}</span>
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <FilterDialogContent />
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============ FILTER CONTENT ============
function FilterDialogContent() {
  const { language, filters, setFilters } = useAppStore()
  const ageOptions = t('ageOptions', language) as string[]
  const categoryOptions = t('categoryOptions', language) as string[]

  return (
    <>
      <DialogHeader>
        <DialogTitle className="text-lg font-semibold">{t('filters', language)}</DialogTitle>
      </DialogHeader>
      <div className="space-y-5 py-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">{t('age', language)}</label>
          <Select
            value={filters.age}
            onValueChange={(v) => setFilters({ ...filters, age: v === 'all' ? '' : v })}
          >
            <SelectTrigger className="rounded-xl">
              <SelectValue placeholder={t('agePlaceholder', language)} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('ageAll', language)}</SelectItem>
              {ageOptions.map((opt, i) => (
                <SelectItem key={i} value={opt}>{opt}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">{t('category', language)}</label>
          <Select
            value={filters.category}
            onValueChange={(v) => setFilters({ ...filters, category: v })}
          >
            <SelectTrigger className="rounded-xl">
              <SelectValue placeholder={t('categoryPlaceholder', language)} />
            </SelectTrigger>
            <SelectContent>
              {categoryOptions.map((opt, i) => (
                <SelectItem key={i} value={opt}>
                  {opt === 'All' ? t('categoryAll', language) : opt}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </>
  )
}

// ============ HOME SCREEN ============
function HomeScreen() {
  const { language, searchQuery, setSearchQuery, filters } = useAppStore()
  const [allSchemes, setAllSchemes] = useState<Scheme[]>([])
  const [loading, setLoading] = useState(true)
  const { selectSector } = useAppStore()

  useEffect(() => {
    fetchSchemes()
  }, [])

  const fetchSchemes = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (searchQuery) params.set('search', searchQuery)
      if (filters.age) {
        const ageMap: Record<string, number> = {
          'Under 18': 17, '18 से कम': 17, '18-25': 25, '25-35': 35,
          '35-50': 50, '50-60': 60, '60+': 60,
        }
        const ageVal = ageMap[filters.age]
        if (ageVal) params.set('age', String(ageVal))
      }
      if (filters.category) params.set('category', filters.category)
      
      const res = await fetch(`/api/schemes?${params.toString()}`)
      if (res.ok) {
        const data = await res.json()
        setAllSchemes(data)
      }
    } catch (err) {
      console.error('Failed to fetch schemes:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const timer = setTimeout(fetchSchemes, 300)
    return () => clearTimeout(timer)
  }, [searchQuery, filters])

  // Group schemes by sector
  const schemesBySector = useMemo(() => {
    const map = new Map<string, Scheme[]>()
    allSchemes.forEach(s => {
      const list = map.get(s.sector) || []
      list.push(s)
      map.set(s.sector, list)
    })
    return map
  }, [allSchemes])

  return (
    <div className="space-y-5">
      <div className="text-center space-y-1.5 pt-2">
        <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
          {language === 'hi' ? '🇮🇳 भारत सरकार योजनाएं' : '🇮🇳 Government of India Schemes'}
        </h2>
        <p className="text-sm text-gray-500">
          {t('appSubtitle', language)}
        </p>
        {!loading && (
          <p className="text-xs text-orange-600 font-medium">
            {allSchemes.length} {t('totalSchemes', language)}
          </p>
        )}
      </div>

      <SearchBar
        value={searchQuery}
        onChange={setSearchQuery}
        onFilterClick={() => {}}
      />

      {/* Filter badges */}
      {(filters.age || filters.category) && (
        <div className="flex flex-wrap gap-2">
          {filters.age && (
            <Badge variant="secondary" className="bg-orange-50 text-orange-700 border-orange-200 px-3 py-1 rounded-full text-xs">
              {t('age', language)}: {filters.age}
              <button onClick={() => useAppStore.getState().setFilters({ ...filters, age: '' })} className="ml-1.5 hover:text-orange-900">×</button>
            </Badge>
          )}
          {filters.category && (
            <Badge variant="secondary" className="bg-orange-50 text-orange-700 border-orange-200 px-3 py-1 rounded-full text-xs">
              {t('category', language)}: {filters.category}
              <button onClick={() => useAppStore.getState().setFilters({ ...filters, category: '' })} className="ml-1.5 hover:text-orange-900">×</button>
            </Badge>
          )}
        </div>
      )}

      {/* Loading skeleton */}
      {loading && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))}
        </div>
      )}

      {/* Sector Grid */}
      {!loading && !searchQuery && (
        <div>
          <h3 className="text-sm font-semibold text-gray-700 mb-3 px-0.5">{t('sectors', language)}</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {sectors.map((sector) => {
              const sectorSchemes = schemesBySector.get(sectorKeyMap[sector.key] || '')
              const count = sectorSchemes?.length || 0
              return (
                <button
                  key={sector.key}
                  onClick={() => selectSector(sector.key)}
                  className={`group relative p-4 rounded-2xl border border-gray-100 ${sector.bgColor} hover:shadow-md hover:scale-[1.02] transition-all duration-200 text-left overflow-hidden`}
                >
                  <div className={`w-10 h-10 rounded-xl bg-white/80 shadow-sm flex items-center justify-center mb-3 ${sector.color}`}>
                    <DynamicIcon name={sector.icon} size={20} />
                  </div>
                  <p className={`text-sm font-semibold leading-snug ${sector.color}`}>
                    {language === 'hi' ? sector.nameHi : sector.nameEn}
                  </p>
                  {count > 0 && (
                    <span className="text-[10px] text-gray-500 font-medium mt-1 block">
                      {count} {language === 'hi' ? 'योजनाएं' : 'schemes'}
                    </span>
                  )}
                  <div className="absolute -right-2 -bottom-2 w-16 h-16 rounded-full bg-white/30 group-hover:bg-white/50 transition-colors" />
                </button>
              )
            })}
          </div>
        </div>
      )}

      {/* Search Results */}
      {!loading && searchQuery && (
        <SearchResults schemes={allSchemes} />
      )}
    </div>
  )
}

// ============ SEARCH RESULTS ============
function SearchResults({ schemes }: { schemes: Scheme[] }) {
  const { language, selectScheme, selectedSector, selectSector } = useAppStore()

  if (schemes.length === 0) {
    return (
      <div className="text-center py-16 space-y-3">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/><path d="m8 11 6 0"/>
          </svg>
        </div>
        <p className="text-base font-medium text-gray-700">{t('noResults', language)}</p>
        <p className="text-sm text-gray-500">{t('noResultsDesc', language)}</p>
      </div>
    )
  }

  // Group by sector
  const grouped = new Map<string, Scheme[]>()
  schemes.forEach(s => {
    const list = grouped.get(s.sector) || []
    list.push(s)
    grouped.set(s.sector, list)
  })

  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-600 font-medium">{schemes.length} {t('totalSchemes', language)}</p>
      {Array.from(grouped.entries()).map(([sector, sectorSchemes]) => (
        <div key={sector} className="space-y-2">
          <button 
            onClick={() => selectSector(sectors.find(s => {
              const dbKey = sectorKeyMap[s.key]
              return dbKey === sector
            })?.key || sector)}
            className="flex items-center gap-2 text-sm font-semibold text-gray-700 hover:text-orange-600 transition-colors"
          >
            <span>{getSectorName(
              sectors.find(s => sectorKeyMap[s.key] === sector)?.key || sector,
              language
            )}</span>
            <span className="text-xs text-gray-400">({sectorSchemes.length})</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-gray-400">
              <path d="m9 18 6-6-6-6"/>
            </svg>
          </button>
          <div className="space-y-2">
            {sectorSchemes.map(scheme => (
              <SchemeCard key={scheme.id} scheme={scheme} />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

// ============ SCHEME LIST SCREEN ============
function SchemeListScreen() {
  const { selectedSector, language, selectScheme, goHome } = useAppStore()
  const [schemes, setSchemes] = useState<Scheme[]>([])
  const [loading, setLoading] = useState(true)

  const dbSectorKey = sectorKeyMap[selectedSector || ''] || selectedSector

  useEffect(() => {
    if (!dbSectorKey) { goHome(); return }
    fetchSchemes()
  }, [dbSectorKey])

  const fetchSchemes = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/schemes?sector=${encodeURIComponent(dbSectorKey)}`)
      if (res.ok) {
        const data = await res.json()
        setSchemes(data)
      }
    } catch (err) {
      console.error('Failed to fetch sector schemes:', err)
    } finally {
      setLoading(false)
    }
  }

  const sectorConfig = getSectorConfig(selectedSector || '')

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48 rounded-lg" />
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Sector Header */}
      <div className={`${sectorConfig?.bgColor || 'bg-gray-50'} rounded-2xl p-5 flex items-center gap-4`}>
        <div className={`w-12 h-12 rounded-xl bg-white/80 shadow-sm flex items-center justify-center ${sectorConfig?.color || 'text-gray-700'}`}>
          {sectorConfig && <DynamicIcon name={sectorConfig.icon} size={24} />}
        </div>
        <div>
          <h2 className="text-lg font-bold text-gray-900">
            {getSectorName(selectedSector || '', language)}
          </h2>
          <p className="text-sm text-gray-500">
            {schemes.length} {t('forSector', language)}
          </p>
        </div>
      </div>

      {/* Schemes */}
      {schemes.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <p className="text-base font-medium text-gray-700">{t('noResults', language)}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {schemes.map(scheme => (
            <SchemeCard key={scheme.id} scheme={scheme} />
          ))}
        </div>
      )}
    </div>
  )
}

// ============ SCHEME CARD ============
function SchemeCard({ scheme }: { scheme: Scheme }) {
  const { language, selectScheme, bookmarks, toggleBookmark } = useAppStore()
  const isBookmarked = bookmarks.includes(scheme.id)

  return (
    <Card className="group border border-gray-100 hover:border-orange-200 hover:shadow-md transition-all duration-200 overflow-hidden rounded-2xl">
      <CardContent className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <h3 className="text-base font-semibold text-gray-900 leading-snug mb-1.5 line-clamp-2">
              {language === 'hi' ? scheme.nameHi : scheme.schemeName}
            </h3>
            <p className="text-sm text-gray-500 leading-relaxed line-clamp-2">
              {language === 'hi' ? scheme.descriptionHi : scheme.description}
            </p>
            <div className="flex flex-wrap gap-1.5 mt-2.5">
              {scheme.category !== 'All' && (
                <Badge variant="secondary" className="bg-blue-50 text-blue-700 text-[10px] px-2 py-0.5 rounded-full font-medium">
                  {scheme.category}
                </Badge>
              )}
              {scheme.ageMin && (
                <Badge variant="secondary" className="bg-green-50 text-green-700 text-[10px] px-2 py-0.5 rounded-full font-medium">
                  {scheme.ageMin}+ {language === 'hi' ? 'वर्ष' : 'yrs'}
                </Badge>
              )}
              <Badge variant="secondary" className="bg-gray-50 text-gray-600 text-[10px] px-2 py-0.5 rounded-full font-medium">
                {getSectorName(
                  sectors.find(s => sectorKeyMap[s.key] === scheme.sector)?.key || scheme.sector,
                  language
                )}
              </Badge>
            </div>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); toggleBookmark(scheme.id) }}
            className="p-2 rounded-full hover:bg-gray-50 transition-colors shrink-0"
            aria-label="Bookmark"
          >
            {isBookmarked ? (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="#f97316" stroke="#f97316" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
              </svg>
            ) : (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400">
                <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
              </svg>
            )}
          </button>
        </div>
        <div className="mt-3.5 pt-3 border-t border-gray-50">
          <Button
            onClick={() => selectScheme(scheme.id)}
            className="w-full h-9 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium shadow-sm"
          >
            {t('viewDetails', language)}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1.5">
              <path d="m9 18 6-6-6-6"/>
            </svg>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

// ============ SCHEME DETAIL SCREEN ============
function SchemeDetailScreen() {
  const { selectedSchemeId, language, bookmarks, toggleBookmark } = useAppStore()
  const [scheme, setScheme] = useState<Scheme | null>(null)
  const [fetchedId, setFetchedId] = useState<string | null>(null)

  useEffect(() => {
    if (!selectedSchemeId) return
    const controller = new AbortController()
    fetch(`/api/schemes`, { signal: controller.signal })
      .then(res => res.json())
      .then(data => {
        const found = data.find((s: Scheme) => s.id === selectedSchemeId)
        setScheme(found || null)
        setFetchedId(selectedSchemeId)
      })
      .catch((err) => {
        if (err.name !== 'AbortError') console.error(err)
      })
    return () => controller.abort()
  }, [selectedSchemeId])

  const isLoading = !!selectedSchemeId && fetchedId !== selectedSchemeId

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-3/4 rounded-lg" />
        <Skeleton className="h-40 rounded-2xl" />
        <Skeleton className="h-32 rounded-2xl" />
        <Skeleton className="h-32 rounded-2xl" />
        <Skeleton className="h-32 rounded-2xl" />
      </div>
    )
  }

  if (!scheme) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-500">Scheme not found</p>
      </div>
    )
  }

  const isBookmarked = bookmarks.includes(scheme.id)
  const sectorConfig = getSectorConfig(
    sectors.find(s => sectorKeyMap[s.key] === scheme.sector)?.key || scheme.sector
  )

  return (
    <div className="space-y-4">
      {/* Scheme Header */}
      <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-5 text-white relative overflow-hidden">
        <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/10 rounded-full" />
        <div className="absolute -right-4 -bottom-12 w-24 h-24 bg-white/5 rounded-full" />
        
        <div className="relative">
          <div className="flex items-start justify-between gap-3 mb-3">
            <Badge className="bg-white/20 text-white border-0 text-xs px-2.5 py-0.5 rounded-full font-medium backdrop-blur-sm">
              {sectorConfig ? (language === 'hi' ? sectorConfig.nameHi : sectorConfig.nameEn) : scheme.sector}
            </Badge>
            <button
              onClick={() => toggleBookmark(scheme.id)}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors backdrop-blur-sm"
            >
              {isBookmarked ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="white" stroke="white" strokeWidth="2">
                  <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
                </svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
                  <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
                </svg>
              )}
            </button>
          </div>
          <h1 className="text-xl font-bold leading-tight">
            {language === 'hi' ? scheme.nameHi : scheme.schemeName}
          </h1>
        </div>
      </div>

      {/* Description */}
      <Card className="border-gray-100 rounded-2xl">
        <CardContent className="p-4 sm:p-5">
          <p className="text-sm text-gray-600 leading-relaxed">
            {language === 'hi' ? scheme.descriptionHi : scheme.description}
          </p>
        </CardContent>
      </Card>

      {/* Eligibility */}
      <Card className="border-gray-100 rounded-2xl">
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
              </svg>
            </div>
            <h3 className="text-base font-semibold text-gray-900">{t('eligibility', language)}</h3>
          </div>
          <div className="space-y-2 pl-10">
            {(language === 'hi' ? scheme.eligibilityHi : scheme.eligibility).split('. ').filter(Boolean).map((item, i) => (
              <div key={i} className="flex items-start gap-2">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 mt-0.5 shrink-0">
                  <path d="M20 6 9 17l-5-5"/>
                </svg>
                <p className="text-sm text-gray-600 leading-relaxed">{item.trim()}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Documents */}
      <Card className="border-gray-100 rounded-2xl">
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-600">
                <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 18H8"/><path d="M16 18h-2"/><path d="M10 12H8"/><path d="M16 12h-2"/>
              </svg>
            </div>
            <h3 className="text-base font-semibold text-gray-900">{t('documents', language)}</h3>
          </div>
          <div className="space-y-2 pl-10">
            {(language === 'hi' ? scheme.documentsHi : scheme.documents).split(', ').map((doc, i) => (
              <div key={i} className="flex items-center gap-2">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-500 shrink-0">
                  <path d="m9 18 6-6-6-6"/>
                </svg>
                <p className="text-sm text-gray-600">{doc.trim()}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Benefits */}
      <Card className="border-gray-100 rounded-2xl">
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-green-50 flex items-center justify-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
                <circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>
              </svg>
            </div>
            <h3 className="text-base font-semibold text-gray-900">{t('benefits', language)}</h3>
          </div>
          <div className="space-y-2 pl-10">
            {(language === 'hi' ? scheme.benefitsHi : scheme.benefits).split('. ').filter(Boolean).map((item, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-green-100 text-green-700 flex items-center justify-center text-[10px] font-bold mt-0.5 shrink-0">✓</span>
                <p className="text-sm text-gray-600 leading-relaxed">{item.trim()}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Apply Now Button */}
      <a
        href={scheme.applyLink}
        target="_blank"
        rel="noopener noreferrer"
        className="block w-full"
      >
        <Button className="w-full h-12 rounded-xl bg-green-600 hover:bg-green-700 text-white text-base font-semibold shadow-lg shadow-green-600/25 transition-all duration-200 hover:shadow-green-600/40">
          {t('applyNow', language)}
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
          </svg>
        </Button>
      </a>

      <p className="text-center text-xs text-gray-400 pb-2">
        {language === 'hi' ? 'आपको आधिकारिक सरकारी वेबसाइट पर पुनर्निर्देशित किया जाएगा' : 'You will be redirected to the official government website'}
      </p>
    </div>
  )
}

// ============ BOOKMARKS SCREEN ============
function BookmarksScreen() {
  const { bookmarks, language, selectScheme } = useAppStore()
  const [schemes, setSchemes] = useState<Scheme[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchSchemes()
  }, [bookmarks])

  const fetchSchemes = async () => {
    if (bookmarks.length === 0) { setSchemes([]); setLoading(false); return }
    setLoading(true)
    try {
      const res = await fetch('/api/schemes')
      if (res.ok) {
        const data: Scheme[] = await res.json()
        const bookmarked = data.filter(s => bookmarks.includes(s.id))
        setSchemes(bookmarked)
      }
    } catch (err) {
      console.error('Failed to fetch bookmarks:', err)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48 rounded-lg" />
        <div className="space-y-3">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="text-center space-y-1">
        <h2 className="text-lg font-bold text-gray-900">{t('bookmarked', language)}</h2>
        <p className="text-sm text-gray-500">
          {schemes.length} {t('bookmarkedCount', language)}
        </p>
      </div>

      {schemes.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400">
              <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
            </svg>
          </div>
          <p className="text-base font-medium text-gray-700">{t('noBookmarks', language)}</p>
          <p className="text-sm text-gray-500">{t('noBookmarksDesc', language)}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {schemes.map(scheme => (
            <SchemeCard key={scheme.id} scheme={scheme} />
          ))}
        </div>
      )}
    </div>
  )
}

// ============ FOOTER ============
function Footer() {
  const language = useAppStore(s => s.language)
  return (
    <footer className="mt-auto border-t border-gray-100 bg-gray-50/50 py-6">
      <div className="max-w-5xl mx-auto px-4 text-center space-y-2">
        <p className="text-xs text-gray-500">
          {t('footerText', language)}
        </p>
        <p className="text-xs text-gray-400">
          {t('madeWith', language)}
        </p>
      </div>
    </footer>
  )
}

// ============ MAIN APP ============
export default function Home() {
  const { screen, currentUser } = useAppStore()
  const isAuthScreen = screen === 'register' || screen === 'signin'
  const isAdminScreen = screen === 'adminLogin' || screen === 'adminDashboard' || screen === 'adminAddScheme' || screen === 'adminEditScheme'

  // AUTH GATE: Must be logged in to use the app (admin screens exempt)
  if (!currentUser && !isAdminScreen && !isAuthScreen) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50/30">
        <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-5">
          <RegisterScreen />
        </main>
      </div>
    )
  }

  if (isAuthScreen) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50/30">
        <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-5">
          {screen === 'register' && <RegisterScreen />}
          {screen === 'signin' && <SigninScreen />}
        </main>
      </div>
    )
  }

  if (isAdminScreen) {
    return (
      <div className="min-h-screen flex flex-col bg-gray-50/30">
        <AdminHeader />
        <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-5 pb-8">
          {screen === 'adminLogin' && <AdminLoginScreen />}
          {screen === 'adminDashboard' && <AdminDashboard />}
          {screen === 'adminAddScheme' && <AdminAddSchemeScreen />}
          {screen === 'adminEditScheme' && <AdminEditSchemeScreen />}
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50/30">
      <Header />
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-5 pb-20 sm:pb-8">
        {screen === 'home' && <HomeScreen />}
        {screen === 'schemeList' && <SchemeListScreen />}
        {screen === 'schemeDetail' && <SchemeDetailScreen />}
        {screen === 'bookmarks' && <BookmarksScreen />}
      </main>
      <Footer />
      
      {/* Bottom nav for mobile */}
      <BottomNav />
    </div>
  )
}

function BottomNav() {
  const { screen, setScreen, goHome, adminToken, goToAdminDashboard, currentUser } = useAppStore()
  const language = useAppStore(s => s.language)
  const isAdminScreen = screen === 'adminLogin' || screen === 'adminDashboard' || screen === 'adminAddScheme' || screen === 'adminEditScheme'
  const isAuthScreen = screen === 'register' || screen === 'signin'

  if (isAdminScreen || isAuthScreen) return null

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 shadow-[0_-2px_10px_rgba(0,0,0,0.05)] sm:hidden z-50">
      <div className="flex items-center justify-around h-14 px-2">
        <button
          onClick={goHome}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors ${screen === 'home' ? 'text-orange-600' : 'text-gray-500'}`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
          </svg>
          <span className="text-[10px] font-medium">{t('home', language)}</span>
        </button>
        <button
          onClick={() => setScreen('bookmarks')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors ${screen === 'bookmarks' ? 'text-orange-600' : 'text-gray-500'}`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
          </svg>
          <span className="text-[10px] font-medium">{t('bookmarks', language)}</span>
        </button>
        {currentUser ? (
          <button
            onClick={() => useAppStore.getState().signOutUser()}
            className="flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors text-red-500"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            <span className="text-[10px] font-medium">Logout</span>
          </button>
        ) : (
          <button
            onClick={() => setScreen('register')}
            className="flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors text-orange-600"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/>
            </svg>
            <span className="text-[10px] font-medium">Register</span>
          </button>
        )}
        <button
          onClick={() => adminToken ? goToAdminDashboard() : setScreen('adminLogin')}
          className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors ${adminToken ? 'text-green-600' : 'text-gray-500'}`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          <span className="text-[10px] font-medium">Admin</span>
        </button>
      </div>
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  )
}
