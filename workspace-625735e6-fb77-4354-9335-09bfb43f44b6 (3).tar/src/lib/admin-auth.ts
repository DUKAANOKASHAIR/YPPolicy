import { NextRequest } from 'next/server'

const ADMIN_EMAIL = 'deepanshu19gaur@gmail.com'
const ADMIN_PASSWORD = 'Admin@2024'

export function generateAdminToken(email: string, password: string): string | null {
  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    const payload = JSON.stringify({
      email: ADMIN_EMAIL,
      exp: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    })
    return Buffer.from(payload).toString('base64')
  }
  return null
}

export function verifyAdminToken(request: NextRequest): boolean {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return false
    }

    const token = authHeader.substring(7)
    const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'))

    if (decoded.email !== ADMIN_EMAIL) {
      return false
    }

    if (decoded.exp && decoded.exp < Date.now()) {
      return false
    }

    return true
  } catch {
    return false
  }
}
