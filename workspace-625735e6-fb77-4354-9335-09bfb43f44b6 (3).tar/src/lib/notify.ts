import { db } from '@/lib/db'
import nodemailer from 'nodemailer'

// Gmail SMTP transporter
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 465,
  secure: true,
  auth: {
    user: 'youthpolite@gmail.com',
    pass: 'glipnjhfabpsscbs',
  },
})

const ADMIN_EMAIL = 'youthpolite@gmail.com'

export async function sendUserNotificationEmail(user: {
  name: string
  phone: string
  address: string
  action: 'register' | 'signin'
}) {
  const isNew = user.action === 'register'
  const subject = isNew
    ? `🆕 New Registration - ${user.name}`
    : `🔄 User Signed In - ${user.name}`

  const htmlBody = `
    <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f4f4f5; border-radius: 12px; overflow: hidden;">
      <div style="background: linear-gradient(135deg, #f97316, #ea580c); padding: 28px 24px; text-align: center;">
        <h1 style="color: white; margin: 0; font-size: 22px; font-weight: 700;">Youth Polite for Policy</h1>
        <p style="color: rgba(255,255,255,0.85); margin: 6px 0 0; font-size: 13px;">Government Schemes Portal - User Notification</p>
      </div>
      <div style="background: white; padding: 28px 24px; border-bottom: 1px solid #e5e7eb;">
        <h2 style="color: #111827; margin: 0 0 6px; font-size: 18px;">
          ${isNew ? '🆕 New User Registered' : '🔄 Existing User Signed In'}
        </h2>
        <p style="color: #9ca3af; margin: 0 0 20px; font-size: 13px;">${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', dateStyle: 'medium', timeStyle: 'short' })}</p>
      </div>
      <div style="background: white; padding: 0 24px 28px;">
        <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
          <tr>
            <td style="padding: 14px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-weight: 600; width: 110px;">👤 Name</td>
            <td style="padding: 14px 0; border-bottom: 1px solid #f3f4f6; color: #111827; font-weight: 500;">${user.name}</td>
          </tr>
          <tr>
            <td style="padding: 14px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-weight: 600;">📱 Phone</td>
            <td style="padding: 14px 0; border-bottom: 1px solid #f3f4f6; color: #111827; font-weight: 500;">${user.phone}</td>
          </tr>
          <tr>
            <td style="padding: 14px 0; border-bottom: 1px solid #f3f4f6; color: #6b7280; font-weight: 600;">📍 Address</td>
            <td style="padding: 14px 0; border-bottom: 1px solid #f3f4f6; color: #111827; font-weight: 500;">${user.address}</td>
          </tr>
          <tr>
            <td style="padding: 14px 0; color: #6b7280; font-weight: 600;">📌 Action</td>
            <td style="padding: 14px 0;">
              <span style="display:inline-block; background: ${isNew ? '#dcfce7' : '#dbeafe'}; color: ${isNew ? '#166534' : '#1e40af'}; padding: 4px 14px; border-radius: 9999px; font-size: 12px; font-weight: 700;">
                ${isNew ? '✅ NEW REGISTRATION' : '🔑 SIGN IN'}
              </span>
            </td>
          </tr>
        </table>
      </div>
      <div style="background: #f9fafb; padding: 16px 24px; text-align: center; border-top: 1px solid #e5e7eb;">
        <p style="color: #9ca3af; font-size: 12px; margin: 0;">This is an automated notification from Youth Polite for Policy.</p>
      </div>
    </div>
  `

  try {
    const info = await transporter.sendMail({
      from: `"YPP Portal" <youthpolite@gmail.com>`,
      to: ADMIN_EMAIL,
      subject,
      html: htmlBody,
    })
    console.log(`✅ Email sent: ${info.messageId}`)
    return true
  } catch (error) {
    console.error('❌ Email failed:', error)
    return false
  }
}

export async function logUserNotification(user: {
  name: string
  phone: string
  address: string
  action: 'register' | 'signin'
}) {
  const emailSent = await sendUserNotificationEmail(user)

  try {
    await db.userNotification.create({
      data: {
        userName: user.name,
        userPhone: user.phone,
        userAddress: user.address,
        action: user.action,
        sentTo: 'youthpolite@gmail.com',
      },
    })
  } catch (error) {
    console.error('DB log failed:', error)
  }

  return emailSent
}
