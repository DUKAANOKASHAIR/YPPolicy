export interface SectorConfig {
  key: string
  nameEn: string
  nameHi: string
  icon: string
  color: string
  bgColor: string
}

export const sectors: SectorConfig[] = [
  {
    key: "Agriculture & Farmers",
    nameEn: "Agriculture & Farmers",
    nameHi: "कृषि एवं किसान",
    icon: "Wheat",
    color: "text-green-700",
    bgColor: "bg-green-50",
  },
  {
    key: "Education",
    nameEn: "Education",
    nameHi: "शिक्षा",
    icon: "GraduationCap",
    color: "text-blue-700",
    bgColor: "bg-blue-50",
  },
  {
    key: "Employment & Skill Development",
    nameEn: "Employment & Skill Dev",
    nameHi: "रोजगार एवं कौशल विकास",
    icon: "Briefcase",
    color: "text-amber-700",
    bgColor: "bg-amber-50",
  },
  {
    key: "Startup & Business",
    nameEn: "Startup & Business",
    nameHi: "स्टार्टअप एवं व्यवसाय",
    icon: "Rocket",
    color: "text-purple-700",
    bgColor: "bg-purple-50",
  },
  {
    key: "Youth Development",
    nameEn: "Youth Development",
    nameHi: "युवा विकास",
    icon: "Users",
    color: "text-orange-700",
    bgColor: "bg-orange-50",
  },
  {
    key: "Women Empowerment",
    nameEn: "Women Empowerment",
    nameHi: "महिला सशक्तिकरण",
    icon: "Heart",
    color: "text-pink-700",
    bgColor: "bg-pink-50",
  },
  {
    key: "Child Welfare",
    nameEn: "Child Welfare",
    nameHi: "बाल कल्याण",
    icon: "Baby",
    color: "text-rose-700",
    bgColor: "bg-rose-50",
  },
  {
    key: "Health & Medical",
    nameEn: "Health & Medical",
    nameHi: "स्वास्थ्य एवं चिकित्सा",
    icon: "Stethoscope",
    color: "text-red-700",
    bgColor: "bg-red-50",
  },
  {
    key: "Housing & Urban Dev",
    nameEn: "Housing & Urban Dev",
    nameHi: "आवास एवं शहरी विकास",
    icon: "Building2",
    color: "text-cyan-700",
    bgColor: "bg-cyan-50",
  },
  {
    key: "Rural Development",
    nameEn: "Rural Development",
    nameHi: "ग्रामीण विकास",
    icon: "Trees",
    color: "text-emerald-700",
    bgColor: "bg-emerald-50",
  },
  {
    key: "Water & Sanitation",
    nameEn: "Water & Sanitation",
    nameHi: "जल एवं स्वच्छता",
    icon: "Droplets",
    color: "text-sky-700",
    bgColor: "bg-sky-50",
  },
  {
    key: "Energy & Electricity",
    nameEn: "Energy & Electricity",
    nameHi: "ऊर्जा एवं विद्युत",
    icon: "Zap",
    color: "text-yellow-700",
    bgColor: "bg-yellow-50",
  },
  {
    key: "Environment",
    nameEn: "Environment",
    nameHi: "पर्यावरण",
    icon: "Leaf",
    color: "text-lime-700",
    bgColor: "bg-lime-50",
  },
  {
    key: "Senior Citizens",
    nameEn: "Senior Citizens",
    nameHi: "वरिष्ठ नागरिक",
    icon: "HeartHandshake",
    color: "text-indigo-700",
    bgColor: "bg-indigo-50",
  },
  {
    key: "Divyang Support",
    nameEn: "Divyang Support",
    nameHi: "दिव्यांग सहायता",
    icon: "Accessibility",
    color: "text-teal-700",
    bgColor: "bg-teal-50",
  },
  {
    key: "Social Welfare",
    nameEn: "Social Welfare",
    nameHi: "सामाजिक कल्याण",
    icon: "HandHeart",
    color: "text-fuchsia-700",
    bgColor: "bg-fuchsia-50",
  },
  {
    key: "Defence & Ex-Servicemen",
    nameEn: "Defence & Ex-Servicemen",
    nameHi: "रक्षा एवं भूतपूर्व सैनिक",
    icon: "Shield",
    color: "text-slate-700",
    bgColor: "bg-slate-50",
  },
  {
    key: "Transport & Infra",
    nameEn: "Transport & Infra",
    nameHi: "परिवहन एवं बुनियादी ढांचा",
    icon: "TrainFront",
    color: "text-stone-700",
    bgColor: "bg-stone-50",
  },
  {
    key: "Digital & Technology",
    nameEn: "Digital & Technology",
    nameHi: "डिजिटल एवं प्रौद्योगिकी",
    icon: "Laptop",
    color: "text-violet-700",
    bgColor: "bg-violet-50",
  },
  {
    key: "Food & Nutrition",
    nameEn: "Food & Nutrition",
    nameHi: "भोजन एवं पोषण",
    icon: "UtensilsCrossed",
    color: "text-orange-700",
    bgColor: "bg-orange-50",
  },
  {
    key: "Industry & Manufacturing",
    nameEn: "Industry & Manufacturing",
    nameHi: "उद्योग एवं विनिर्माण",
    icon: "Factory",
    color: "text-zinc-700",
    bgColor: "bg-zinc-50",
  },
  {
    key: "Allied Rural Livelihood",
    nameEn: "Allied Rural Livelihood",
    nameHi: "सहायक ग्रामीण आजीविका",
    icon: "Sprout",
    color: "text-green-700",
    bgColor: "bg-green-50",
  },
]

export const sectorKeyMap: Record<string, string> = {
  "Agriculture & Farmers": "Agriculture & Farmers",
  "Education": "Education",
  "Employment & Skill Development": "Employment & Skill Development",
  "Startup & Business": "Startup & Business",
  "Youth Development": "Youth Development",
  "Women Empowerment": "Women Empowerment",
  "Child Welfare": "Child Welfare",
  "Health & Medical": "Health & Medical",
  "Housing & Urban Dev": "Housing & Urban Development",
  "Rural Development": "Rural Development",
  "Water & Sanitation": "Water & Sanitation",
  "Energy & Electricity": "Energy & Electricity",
  "Environment": "Environment & Sustainability",
  "Senior Citizens": "Senior Citizens",
  "Divyang Support": "Divyang (Disability Support)",
  "Social Welfare": "Social Welfare & Poverty",
  "Defence & Ex-Servicemen": "Defence & Ex-Servicemen",
  "Transport & Infra": "Transport & Infrastructure",
  "Digital & Technology": "Digital & Technology",
  "Food & Nutrition": "Food & Nutrition",
  "Industry & Manufacturing": "Industry & Manufacturing",
  "Allied Rural Livelihood": "Allied Rural Livelihood",
}

export function getSectorName(key: string, lang: 'en' | 'hi'): string {
  const sector = sectors.find(s => s.key === key)
  if (!sector) return key
  return lang === 'hi' ? sector.nameHi : sector.nameEn
}

export function getSectorConfig(sectorKey: string): SectorConfig | undefined {
  // First try exact match
  let config = sectors.find(s => s.key === sectorKey)
  if (config) return config
  
  // Try matching by checking sectorKeyMap
  for (const [displayKey, dbKey] of Object.entries(sectorKeyMap)) {
    if (dbKey === sectorKey || displayKey === sectorKey) {
      return sectors.find(s => s.key === displayKey)
    }
  }
  
  return undefined
}
