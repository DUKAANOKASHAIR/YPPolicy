'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/store/useAppStore'
import { sectors, sectorKeyMap } from '@/lib/sectors'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/separator'
import { toast } from 'sonner'

interface Scheme {
  id: string
  sector: string
  schemeName: string
  nameHi: string
  description: string
  descriptionHi: string
  eligibility: string
  eligibilityHi: string
  documents: string
  documentsHi: string
  benefits: string
  benefitsHi: string
  applyLink: string
  ageMin: number | null
  ageMax: number | null
  incomeMax: number | null
  category: string
  createdAt: string
  updatedAt: string
}

// ==================== ADMIN LOGIN SCREEN ====================
export function AdminLoginScreen() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { setAdminToken, setAdminEmail, goToAdminDashboard, goBack } = useAppStore()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const res = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Login failed')
        return
      }

      setAdminToken(data.token)
      setAdminEmail(data.email)
      toast.success('Welcome Admin!')
      goToAdminDashboard()
    } catch (err) {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-8">
      <Card className="w-full max-w-md shadow-xl border-gray-200 rounded-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-orange-500 to-amber-500 p-6 text-center">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-3">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
          </div>
          <h2 className="text-xl font-bold text-white">Admin Panel</h2>
          <p className="text-sm text-white/80 mt-1">Youth Polite for Policy</p>
        </div>
        <CardContent className="p-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
            {error && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
                {error}
              </div>
            )}
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-11 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold shadow-lg shadow-orange-500/25"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                  </svg>
                  Signing in...
                </span>
              ) : 'Sign In'}
            </Button>
          </form>
          <div className="mt-4 text-center">
            <Button
              variant="ghost"
              onClick={goBack}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              ← Back to Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== ADMIN DASHBOARD ====================
export function AdminDashboard() {
  const {
    adminToken,
    adminEmail,
    adminSearchQuery,
    setAdminSearchQuery,
    adminSectorFilter,
    setAdminSectorFilter,
    goToAdminAddScheme,
    goToAdminEditScheme,
    goBack,
    adminLogout,
    goHome,
  } = useAppStore()

  const [schemes, setSchemes] = useState<Scheme[]>([])
  const [totalSchemes, setTotalSchemes] = useState(0)
  const [loading, setLoading] = useState(true)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [schemeToDelete, setSchemeToDelete] = useState<Scheme | null>(null)
  const [deleting, setDeleting] = useState(false)

  const fetchSchemes = useCallback(async () => {
    if (!adminToken) return
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (adminSearchQuery) params.set('search', adminSearchQuery)
      if (adminSectorFilter && adminSectorFilter !== 'All') {
        params.set('sector', sectorKeyMap[adminSectorFilter] || adminSectorFilter)
      }
      params.set('limit', '100')

      const res = await fetch(`/api/admin/schemes?${params.toString()}`, {
        headers: { 'Authorization': `Bearer ${adminToken}` },
      })
      if (res.ok) {
        const data = await res.json()
        setSchemes(data.schemes)
        setTotalSchemes(data.total)
      } else {
        // Token expired
        useAppStore.getState().adminLogout()
      }
    } catch (err) {
      console.error('Failed to fetch admin schemes:', err)
    } finally {
      setLoading(false)
    }
  }, [adminToken, adminSearchQuery, adminSectorFilter])

  useEffect(() => {
    fetchSchemes()
  }, [fetchSchemes])

  const handleDelete = async () => {
    if (!adminToken || !schemeToDelete) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/admin/schemes/${schemeToDelete.id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${adminToken}` },
      })
      if (res.ok) {
        toast.success('Scheme deleted successfully')
        setDeleteDialogOpen(false)
        setSchemeToDelete(null)
        fetchSchemes()
      }
    } catch (err) {
      toast.error('Failed to delete scheme')
    } finally {
      setDeleting(false)
    }
  }

  const sectorCounts: Record<string, number> = {}
  schemes.forEach((s) => {
    sectorCounts[s.sector] = (sectorCounts[s.sector] || 0) + 1
  })

  return (
    <div className="space-y-5">
      {/* Admin Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl p-5 text-white relative overflow-hidden">
        <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/5 rounded-full" />
        <div className="absolute -right-4 -bottom-12 w-24 h-24 bg-white/5 rounded-full" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-bold">Admin Dashboard</h1>
              <p className="text-sm text-white/70">{adminEmail}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              onClick={goHome}
              className="text-white/70 hover:text-white hover:bg-white/10 text-sm"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
              Home
            </Button>
            <Button
              variant="ghost"
              onClick={adminLogout}
              className="text-red-300 hover:text-red-200 hover:bg-red-500/20 text-sm"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
              </svg>
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-gray-100 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-600">
                  <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/>
                </svg>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{totalSchemes}</p>
                <p className="text-xs text-gray-500">Total Schemes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-gray-100 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                  <rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>
                </svg>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{Object.keys(sectorCounts).length}</p>
                <p className="text-xs text-gray-500">Sectors</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-gray-100 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">Active</p>
                <p className="text-xs text-gray-500">Status</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-gray-100 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-600">
                  <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>
                </svg>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">Admin</p>
                <p className="text-xs text-gray-500">Role</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
          </svg>
          <Input
            placeholder="Search schemes..."
            value={adminSearchQuery}
            onChange={(e) => setAdminSearchQuery(e.target.value)}
            className="pl-10 h-11 rounded-xl border-gray-200 bg-gray-50/50"
          />
        </div>
        <Select
          value={adminSectorFilter}
          onValueChange={setAdminSectorFilter}
        >
          <SelectTrigger className="h-11 rounded-xl border-gray-200 w-full sm:w-48">
            <SelectValue placeholder="Filter by sector" />
          </SelectTrigger>
          <SelectContent className="max-h-64 overflow-y-auto">
            <SelectItem value="All">All Sectors</SelectItem>
            {sectors.map((s) => (
              <SelectItem key={s.key} value={s.key}>{s.nameEn}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          onClick={goToAdminAddScheme}
          className="h-11 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold shadow-lg shadow-orange-500/25 px-6"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
            <path d="M5 12h14"/><path d="M12 5v14"/>
          </svg>
          Add Scheme
        </Button>
      </div>

      {/* Schemes Table */}
      <Card className="border-gray-100 rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          {/* Desktop Table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Scheme Name</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Sector</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Category</th>
                  <th className="text-left px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Created</th>
                  <th className="text-right px-5 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {loading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i}>
                      <td colSpan={5} className="px-5 py-4">
                        <div className="h-4 bg-gray-100 rounded animate-pulse w-3/4" />
                      </td>
                    </tr>
                  ))
                ) : schemes.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-5 py-16 text-center">
                      <div className="space-y-2">
                        <p className="text-gray-500">No schemes found</p>
                        <Button onClick={goToAdminAddScheme} variant="outline" size="sm" className="rounded-xl">
                          Add your first scheme
                        </Button>
                      </div>
                    </td>
                  </tr>
                ) : (
                  schemes.map((scheme) => (
                    <tr key={scheme.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-5 py-4">
                        <div>
                          <p className="text-sm font-semibold text-gray-900 line-clamp-1">{scheme.schemeName}</p>
                          <p className="text-xs text-gray-500 line-clamp-1 mt-0.5">{scheme.nameHi}</p>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <Badge variant="secondary" className="bg-orange-50 text-orange-700 text-xs rounded-full px-2.5">
                          {scheme.sector}
                        </Badge>
                      </td>
                      <td className="px-5 py-4">
                        <Badge variant="secondary" className="bg-blue-50 text-blue-700 text-xs rounded-full px-2.5">
                          {scheme.category}
                        </Badge>
                      </td>
                      <td className="px-5 py-4 text-xs text-gray-500">
                        {new Date(scheme.createdAt).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </td>
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => goToAdminEditScheme(scheme.id)}
                            className="h-8 px-3 rounded-lg text-blue-600 hover:bg-blue-50 text-xs font-medium"
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                              <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>
                            </svg>
                            Edit
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSchemeToDelete(scheme)
                              setDeleteDialogOpen(true)
                            }}
                            className="h-8 px-3 rounded-lg text-red-600 hover:bg-red-50 text-xs font-medium"
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                              <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>
                            </svg>
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden divide-y divide-gray-100">
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="p-4 space-y-2">
                  <div className="h-4 bg-gray-100 rounded animate-pulse w-3/4" />
                  <div className="h-3 bg-gray-100 rounded animate-pulse w-1/2" />
                </div>
              ))
            ) : schemes.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-gray-500 text-sm">No schemes found</p>
              </div>
            ) : (
              schemes.map((scheme) => (
                <div key={scheme.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 line-clamp-2">{scheme.schemeName}</p>
                      <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">{scheme.nameHi}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <Badge variant="secondary" className="bg-orange-50 text-orange-700 text-[10px] rounded-full px-2">
                      {scheme.sector}
                    </Badge>
                    <Badge variant="secondary" className="bg-blue-50 text-blue-700 text-[10px] rounded-full px-2">
                      {scheme.category}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 pt-1">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => goToAdminEditScheme(scheme.id)}
                      className="flex-1 h-8 rounded-lg text-xs font-medium"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                        <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
                      </svg>
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSchemeToDelete(scheme)
                        setDeleteDialogOpen(true)
                      }}
                      className="flex-1 h-8 rounded-lg text-xs font-medium text-red-600 border-red-200 hover:bg-red-50"
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                        <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                      </svg>
                      Delete
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Table Footer */}
          {!loading && schemes.length > 0 && (
            <div className="px-5 py-3 bg-gray-50 border-t border-gray-100 text-xs text-gray-500">
              Showing {schemes.length} of {totalSchemes} schemes
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle>Delete Scheme</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete <strong>&quot;{schemeToDelete?.schemeName}&quot;</strong>? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="rounded-xl"
              disabled={deleting}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleting}
              className="rounded-xl"
            >
              {deleting ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                  </svg>
                  Deleting...
                </span>
              ) : 'Delete Scheme'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ==================== SCHEME FORM (shared between Add & Edit) ====================
function SchemeForm({
  initialData,
  onSubmit,
  submitLabel,
  loading,
}: {
  initialData?: Partial<Scheme>
  onSubmit: (data: Record<string, unknown>) => void
  submitLabel: string
  loading: boolean
}) {
  const [formData, setFormData] = useState({
    sector: initialData?.sector || '',
    schemeName: initialData?.schemeName || '',
    nameHi: initialData?.nameHi || '',
    description: initialData?.description || '',
    descriptionHi: initialData?.descriptionHi || '',
    eligibility: initialData?.eligibility || '',
    eligibilityHi: initialData?.eligibilityHi || '',
    documents: initialData?.documents || '',
    documentsHi: initialData?.documentsHi || '',
    benefits: initialData?.benefits || '',
    benefitsHi: initialData?.benefitsHi || '',
    applyLink: initialData?.applyLink || '',
    ageMin: initialData?.ageMin?.toString() || '',
    ageMax: initialData?.ageMax?.toString() || '',
    incomeMax: initialData?.incomeMax?.toString() || '',
    category: initialData?.category || 'All',
  })

  const updateField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Basic Info */}
      <Card className="border-gray-100 rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-gray-900 flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-orange-50 flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-600">
                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/>
              </svg>
            </div>
            Basic Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Sector *</Label>
              <Select
                value={formData.sector}
                onValueChange={(v) => updateField('sector', v)}
              >
                <SelectTrigger className="rounded-xl border-gray-200">
                  <SelectValue placeholder="Select sector" />
                </SelectTrigger>
                <SelectContent className="max-h-64 overflow-y-auto">
                  {sectors.map((s) => (
                    <SelectItem key={s.key} value={sectorKeyMap[s.key] || s.key}>
                      {s.nameEn} ({s.nameHi})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Category</Label>
              <Select
                value={formData.category}
                onValueChange={(v) => updateField('category', v)}
              >
                <SelectTrigger className="rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {['All', 'General', 'OBC', 'SC', 'ST', 'EWS', 'Women', 'Farmers', 'Students', 'Senior Citizens', 'Divyang'].map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Scheme Name (English) *</Label>
              <Input
                value={formData.schemeName}
                onChange={(e) => updateField('schemeName', e.target.value)}
                placeholder="e.g., Pradhan Mantri Jan Dhan Yojana"
                className="h-11 rounded-xl border-gray-200"
                required
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Scheme Name (Hindi)</Label>
              <Input
                value={formData.nameHi}
                onChange={(e) => updateField('nameHi', e.target.value)}
                placeholder="e.g., प्रधानमंत्री जन धन योजना"
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Min Age</Label>
              <Input
                type="number"
                value={formData.ageMin}
                onChange={(e) => updateField('ageMin', e.target.value)}
                placeholder="e.g., 18"
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Max Age</Label>
              <Input
                type="number"
                value={formData.ageMax}
                onChange={(e) => updateField('ageMax', e.target.value)}
                placeholder="e.g., 60"
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm font-medium text-gray-700">Max Income (₹)</Label>
              <Input
                type="number"
                value={formData.incomeMax}
                onChange={(e) => updateField('incomeMax', e.target.value)}
                placeholder="e.g., 250000"
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Description */}
      <Card className="border-gray-100 rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-gray-900 flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/>
              </svg>
            </div>
            Description
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Description (English) *</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => updateField('description', e.target.value)}
              placeholder="Describe the scheme in English..."
              rows={3}
              className="rounded-xl border-gray-200 resize-none"
              required
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Description (Hindi)</Label>
            <Textarea
              value={formData.descriptionHi}
              onChange={(e) => updateField('descriptionHi', e.target.value)}
              placeholder="योजना का विवरण हिंदी में..."
              rows={3}
              className="rounded-xl border-gray-200 resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Eligibility */}
      <Card className="border-gray-100 rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-gray-900 flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-green-50 flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
              </svg>
            </div>
            Eligibility
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Eligibility (English) *</Label>
            <Textarea
              value={formData.eligibility}
              onChange={(e) => updateField('eligibility', e.target.value)}
              placeholder="Who is eligible? Use periods to separate points..."
              rows={3}
              className="rounded-xl border-gray-200 resize-none"
              required
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Eligibility (Hindi)</Label>
            <Textarea
              value={formData.eligibilityHi}
              onChange={(e) => updateField('eligibilityHi', e.target.value)}
              placeholder="पात्रता हिंदी में..."
              rows={3}
              className="rounded-xl border-gray-200 resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Documents */}
      <Card className="border-gray-100 rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-gray-900 flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-50 flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-600">
                <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>
              </svg>
            </div>
            Required Documents
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Documents (English)</Label>
            <Textarea
              value={formData.documents}
              onChange={(e) => updateField('documents', e.target.value)}
              placeholder="Aadhaar Card, PAN Card, Bank Passbook..."
              rows={2}
              className="rounded-xl border-gray-200 resize-none"
            />
            <p className="text-xs text-gray-400">Separate documents with commas</p>
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Documents (Hindi)</Label>
            <Textarea
              value={formData.documentsHi}
              onChange={(e) => updateField('documentsHi', e.target.value)}
              placeholder="आधार कार्ड, पैन कार्ड, बैंक पासबुक..."
              rows={2}
              className="rounded-xl border-gray-200 resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Benefits */}
      <Card className="border-gray-100 rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-gray-900 flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-50 flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-emerald-600">
                <circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>
              </svg>
            </div>
            Benefits
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Benefits (English) *</Label>
            <Textarea
              value={formData.benefits}
              onChange={(e) => updateField('benefits', e.target.value)}
              placeholder="What benefits does this scheme provide?"
              rows={3}
              className="rounded-xl border-gray-200 resize-none"
              required
            />
          </div>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Benefits (Hindi)</Label>
            <Textarea
              value={formData.benefitsHi}
              onChange={(e) => updateField('benefitsHi', e.target.value)}
              placeholder="इस योजना के लाभ..."
              rows={3}
              className="rounded-xl border-gray-200 resize-none"
            />
          </div>
        </CardContent>
      </Card>

      {/* Apply Link */}
      <Card className="border-gray-100 rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-gray-900 flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-violet-50 flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-violet-600">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
              </svg>
            </div>
            Apply Link
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label className="text-sm font-medium text-gray-700">Application URL *</Label>
            <Input
              type="url"
              value={formData.applyLink}
              onChange={(e) => updateField('applyLink', e.target.value)}
              placeholder="https://example.gov.in/apply"
              className="h-11 rounded-xl border-gray-200"
              required
            />
            <p className="text-xs text-gray-400">Official government website link where users can apply</p>
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex gap-3 pb-8">
        <Button
          type="button"
          variant="outline"
          onClick={useAppStore.getState().goBack}
          className="h-11 px-6 rounded-xl border-gray-200"
          disabled={loading}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={loading}
          className="flex-1 h-11 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold shadow-lg shadow-orange-500/25 sm:flex-none sm:px-8"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
              </svg>
              Saving...
            </span>
          ) : submitLabel}
        </Button>
      </div>
    </form>
  )
}

// ==================== ADD SCHEME SCREEN ====================
export function AdminAddSchemeScreen() {
  const { adminToken, goToAdminDashboard } = useAppStore()
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (data: Record<string, unknown>) => {
    if (!adminToken) return
    setLoading(true)
    try {
      const res = await fetch('/api/admin/schemes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`,
        },
        body: JSON.stringify(data),
      })

      const result = await res.json()

      if (!res.ok) {
        toast.error(result.error || 'Failed to create scheme')
        return
      }

      toast.success('Scheme created successfully!')
      goToAdminDashboard()
    } catch (err) {
      toast.error('Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-orange-600">
            <path d="M5 12h14"/><path d="M12 5v14"/>
          </svg>
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-900">Add New Scheme</h1>
          <p className="text-sm text-gray-500">Fill in the details to add a new government scheme</p>
        </div>
      </div>

      <SchemeForm
        onSubmit={handleSubmit}
        submitLabel="Create Scheme"
        loading={loading}
      />
    </div>
  )
}

// ==================== EDIT SCHEME SCREEN ====================
export function AdminEditSchemeScreen() {
  const { adminToken, selectedSchemeId, goToAdminDashboard } = useAppStore()
  const [scheme, setScheme] = useState<Scheme | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!adminToken || !selectedSchemeId) return

    const fetchScheme = async () => {
      try {
        const res = await fetch(`/api/admin/schemes/${selectedSchemeId}`, {
          headers: { 'Authorization': `Bearer ${adminToken}` },
        })
        if (res.ok) {
          const data = await res.json()
          setScheme(data.scheme)
        } else {
          toast.error('Failed to load scheme')
          goToAdminDashboard()
        }
      } catch (err) {
        toast.error('Something went wrong')
      } finally {
        setLoading(false)
      }
    }

    fetchScheme()
  }, [adminToken, selectedSchemeId])

  const handleSubmit = async (data: Record<string, unknown>) => {
    if (!adminToken || !selectedSchemeId) return
    setSaving(true)
    try {
      const res = await fetch(`/api/admin/schemes/${selectedSchemeId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${adminToken}`,
        },
        body: JSON.stringify(data),
      })

      const result = await res.json()

      if (!res.ok) {
        toast.error(result.error || 'Failed to update scheme')
        return
      }

      toast.success('Scheme updated successfully!')
      goToAdminDashboard()
    } catch (err) {
      toast.error('Something went wrong')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="h-8 w-48 bg-gray-100 rounded-lg animate-pulse" />
        <div className="h-64 bg-gray-100 rounded-2xl animate-pulse" />
      </div>
    )
  }

  if (!scheme) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-500">Scheme not found</p>
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
            <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>
          </svg>
        </div>
        <div>
          <h1 className="text-xl font-bold text-gray-900">Edit Scheme</h1>
          <p className="text-sm text-gray-500">Update the details for &quot;{scheme.schemeName}&quot;</p>
        </div>
      </div>

      <SchemeForm
        initialData={scheme}
        onSubmit={handleSubmit}
        submitLabel="Update Scheme"
        loading={saving}
      />
    </div>
  )
}
