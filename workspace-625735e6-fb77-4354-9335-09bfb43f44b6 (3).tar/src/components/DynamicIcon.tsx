import React from 'react'
import {
  Wheat, GraduationCap, Briefcase, Rocket, Users, Heart, Baby,
  Stethoscope, Building2, Trees, Droplets, Zap, Leaf, HeartHandshake,
  Accessibility, HandHeart, Shield, TrainFront, Laptop, UtensilsCrossed,
  Factory, Sprout, Search, X, ChevronLeft, ChevronRight, Home,
  Bookmark, BookmarkCheck, ExternalLink, Filter, Globe, Menu,
  FileText, CheckCircle2, Award, AlertCircle
} from 'lucide-react'

const iconMap: Record<string, React.ElementType> = {
  Wheat, GraduationCap, Briefcase, Rocket, Users, Heart, Baby,
  Stethoscope, Building2, Trees, Droplets, Zap, Leaf, HeartHandshake,
  Accessibility, HandHeart, Shield, TrainFront, Laptop, UtensilsCrossed,
  Factory, Sprout, Search, X, ChevronLeft, ChevronRight, Home,
  Bookmark, BookmarkCheck, ExternalLink, Filter, Globe, Menu,
  FileText, CheckCircle2, Award, AlertCircle
}

interface DynamicIconProps {
  name: string
  className?: string
  size?: number
}

export function DynamicIcon({ name, className = "", size = 24 }: DynamicIconProps) {
  const IconComponent = iconMap[name]
  if (!IconComponent) return <Wheat className={className} size={size} />
  return <IconComponent className={className} size={size} />
}
