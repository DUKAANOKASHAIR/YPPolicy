'use client'

import React, { useState } from 'react'
import { useAppStore } from '@/store/useAppStore'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'
import { toast } from 'sonner'

// ==================== REGISTER SCREEN ====================
export function RegisterScreen() {
  const [name, setName] = useState('')
  const [address, setAddress] = useState('')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { setScreen, setCurrentUser } = useAppStore()

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const res = await fetch('/api/users/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, address, phone }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Registration failed')
        return
      }

      setCurrentUser(data.user)
      toast.success('Registration successful! Welcome aboard! 🎉')
      setScreen('home')
    } catch (err) {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center py-8">
      <Card className="w-full max-w-md shadow-xl border-gray-200 rounded-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-orange-500 to-amber-500 p-6 text-center">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-3">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
            </svg>
          </div>
          <h2 className="text-xl font-bold text-white">Create Account</h2>
          <p className="text-sm text-white/80 mt-1">Join Youth Polite for Policy</p>
        </div>
        <CardContent className="p-6">
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="reg-name" className="text-sm font-medium text-gray-700">
                Full Name *
              </Label>
              <Input
                id="reg-name"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reg-address" className="text-sm font-medium text-gray-700">
                Address *
              </Label>
              <Input
                id="reg-address"
                placeholder="Village/Town, District, State"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                required
                className="h-11 rounded-xl border-gray-200"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reg-phone" className="text-sm font-medium text-gray-700">
                Phone Number *
              </Label>
              <Input
                id="reg-phone"
                type="tel"
                placeholder="Enter 10-digit mobile number"
                value={phone}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 10)
                  setPhone(val)
                }}
                required
                minLength={10}
                maxLength={10}
                className="h-11 rounded-xl border-gray-200"
              />
              <p className="text-xs text-gray-400">10-digit mobile number without +91</p>
            </div>
            {error && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
                {error}
              </div>
            )}
            <Button
              type="submit"
              disabled={loading || phone.length < 10}
              className="w-full h-11 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold shadow-lg shadow-orange-500/25"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                  </svg>
                  Registering...
                </span>
              ) : 'Register Now'}
            </Button>
          </form>
          <div className="mt-4 text-center space-y-2">
            <p className="text-sm text-gray-500">
              Already registered?{' '}
              <button
                onClick={() => setScreen('signin')}
                className="text-orange-600 font-semibold hover:underline"
              >
                Sign In
              </button>
            </p>
            <button
              onClick={() => setScreen('home')}
              className="text-sm text-gray-400 hover:text-gray-600"
            >
              ← Back to Home
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== SIGN IN SCREEN ====================
export function SigninScreen() {
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { setScreen, setCurrentUser } = useAppStore()

  const handleSignin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const res = await fetch('/api/users/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Sign in failed')
        return
      }

      setCurrentUser(data.user)
      toast.success(`Welcome back, ${data.user.name}! 👋`)
      setScreen('home')
    } catch (err) {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[70vh] flex items-center justify-center py-8">
      <Card className="w-full max-w-md shadow-xl border-gray-200 rounded-2xl overflow-hidden">
        <div className="bg-gradient-to-r from-slate-700 to-slate-900 p-6 text-center">
          <div className="w-16 h-16 bg-white/15 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-3">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>
            </svg>
          </div>
          <h2 className="text-xl font-bold text-white">Welcome Back</h2>
          <p className="text-sm text-white/70 mt-1">Sign in with your phone number</p>
        </div>
        <CardContent className="p-6">
          <form onSubmit={handleSignin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="signin-phone" className="text-sm font-medium text-gray-700">
                Phone Number *
              </Label>
              <Input
                id="signin-phone"
                type="tel"
                placeholder="Enter 10-digit mobile number"
                value={phone}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 10)
                  setPhone(val)
                }}
                required
                minLength={10}
                maxLength={10}
                className="h-11 rounded-xl border-gray-200"
              />
              <p className="text-xs text-gray-400">No OTP required — just your registered number</p>
            </div>
            {error && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm">
                {error}
              </div>
            )}
            <Button
              type="submit"
              disabled={loading || phone.length < 10}
              className="w-full h-11 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-semibold shadow-lg"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                  </svg>
                  Signing in...
                </span>
              ) : 'Sign In'}
            </Button>
          </form>
          <div className="mt-4 text-center space-y-2">
            <p className="text-sm text-gray-500">
              New here?{' '}
              <button
                onClick={() => setScreen('register')}
                className="text-orange-600 font-semibold hover:underline"
              >
                Create Account
              </button>
            </p>
            <button
              onClick={() => setScreen('home')}
              className="text-sm text-gray-400 hover:text-gray-600"
            >
              ← Back to Home
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// ==================== ADMIN USERS TABLE ====================
export function AdminUsersTab() {
  const { adminToken } = useAppStore()
  const [users, setUsers] = useState<{ id: string; name: string; phone: string; address: string; createdAt: string }[]>([])
  const [notifications, setNotifications] = useState<{ id: string; userName: string; userPhone: string; action: string; createdAt: string }[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState<'users' | 'notifications'>('users')

  const fetchData = async () => {
    if (!adminToken) return
    setLoading(true)
    try {
      const res = await fetch('/api/admin/users', {
        headers: { 'Authorization': `Bearer ${adminToken}` },
      })
      if (res.ok) {
        const data = await res.json()
        setUsers(data.users)
        setNotifications(data.notifications)
      }
    } catch (err) {
      console.error('Failed to fetch users:', err)
    } finally {
      setLoading(false)
    }
  }

  React.useEffect(() => {
    fetchData()
  }, [adminToken])

  if (loading) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="h-12 bg-gray-100 rounded-lg animate-pulse" />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-gray-100 rounded-xl w-fit">
        <button
          onClick={() => setTab('users')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${tab === 'users' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
        >
          Registered Users ({users.length})
        </button>
        <button
          onClick={() => setTab('notifications')}
          className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${tab === 'notifications' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
        >
          Notifications ({notifications.length})
        </button>
      </div>

      {tab === 'users' && (
        <div className="border border-gray-100 rounded-xl overflow-hidden">
          {/* Desktop */}
          <div className="hidden sm:block overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Name</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Phone</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Address</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Registered</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {users.length === 0 ? (
                  <tr><td colSpan={4} className="px-4 py-12 text-center text-gray-400 text-sm">No registered users yet</td></tr>
                ) : users.map((u) => (
                  <tr key={u.id} className="hover:bg-gray-50/50">
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">{u.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{u.phone}</td>
                    <td className="px-4 py-3 text-sm text-gray-600 max-w-[200px] truncate">{u.address}</td>
                    <td className="px-4 py-3 text-xs text-gray-500">
                      {new Date(u.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {/* Mobile */}
          <div className="sm:hidden divide-y divide-gray-100">
            {users.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-sm">No registered users yet</div>
            ) : users.map((u) => (
              <div key={u.id} className="p-4 space-y-1">
                <p className="text-sm font-semibold text-gray-900">{u.name}</p>
                <p className="text-xs text-gray-500">📱 {u.phone}</p>
                <p className="text-xs text-gray-500">📍 {u.address}</p>
                <p className="text-[10px] text-gray-400">{new Date(u.createdAt).toLocaleDateString('en-IN')}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'notifications' && (
        <div className="border border-gray-100 rounded-xl overflow-hidden">
          <div className="divide-y divide-gray-100">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-sm">No notifications yet</div>
            ) : notifications.map((n) => (
              <div key={n.id} className="p-4 flex items-start gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${n.action === 'register' ? 'bg-green-50' : 'bg-blue-50'}`}>
                  {n.action === 'register' ? (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-green-600">
                      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/>
                    </svg>
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-blue-600">
                      <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>
                    </svg>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-gray-900">{n.userName}</p>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${n.action === 'register' ? 'bg-green-50 text-green-700' : 'bg-blue-50 text-blue-700'}`}>
                      {n.action === 'register' ? 'REGISTER' : 'SIGN IN'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">{n.userPhone} • {n.createdAt && new Date(n.createdAt).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
