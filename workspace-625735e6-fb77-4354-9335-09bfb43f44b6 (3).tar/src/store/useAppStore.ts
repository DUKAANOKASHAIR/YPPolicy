import { create } from 'zustand'

export type Screen =
  | 'home'
  | 'schemeList'
  | 'schemeDetail'
  | 'bookmarks'
  | 'register'
  | 'signin'
  | 'adminLogin'
  | 'adminDashboard'
  | 'adminAddScheme'
  | 'adminEditScheme'

interface CurrentUser {
  id: string
  name: string
  phone: string
  address?: string
}

interface AppState {
  screen: Screen
  selectedSector: string | null
  selectedSchemeId: string | null
  language: 'en' | 'hi'
  searchQuery: string
  filters: {
    age: string
    category: string
  }
  bookmarks: string[]
  currentUser: CurrentUser | null

  // Admin state
  adminToken: string | null
  adminEmail: string | null
  adminSearchQuery: string
  adminSectorFilter: string

  // Navigation
  setScreen: (screen: Screen) => void
  selectSector: (sector: string) => void
  selectScheme: (id: string) => void
  toggleLanguage: () => void
  setSearchQuery: (query: string) => void
  setFilters: (filters: { age: string; category: string }) => void
  toggleBookmark: (id: string) => void
  isBookmarked: (id: string) => boolean
  goBack: () => void
  goHome: () => void

  // User actions
  setCurrentUser: (user: CurrentUser | null) => void
  signOutUser: () => void

  // Admin actions
  setAdminToken: (token: string | null) => void
  setAdminEmail: (email: string | null) => void
  adminLogout: () => void
  setAdminSearchQuery: (query: string) => void
  setAdminSectorFilter: (sector: string) => void
  goToAdminDashboard: () => void
  goToAdminAddScheme: () => void
  goToAdminEditScheme: (id: string) => void
}

const getInitialBookmarks = (): string[] => {
  if (typeof window !== 'undefined') {
    try {
      const stored = localStorage.getItem('ypp-bookmarks')
      return stored ? JSON.parse(stored) : []
    } catch {
      return []
    }
  }
  return []
}

const getInitialAdminToken = (): string | null => {
  if (typeof window !== 'undefined') {
    try {
      return localStorage.getItem('ypp-admin-token') || null
    } catch {
      return null
    }
  }
  return null
}

const getInitialAdminEmail = (): string | null => {
  if (typeof window !== 'undefined') {
    try {
      return localStorage.getItem('ypp-admin-email') || null
    } catch {
      return null
    }
  }
  return null
}

const getInitialCurrentUser = (): CurrentUser | null => {
  if (typeof window !== 'undefined') {
    try {
      const stored = localStorage.getItem('ypp-current-user')
      return stored ? JSON.parse(stored) : null
    } catch {
      return null
    }
  }
  return null
}

export const useAppStore = create<AppState>((set, get) => ({
  screen: 'home',
  selectedSector: null,
  selectedSchemeId: null,
  language: 'en',
  searchQuery: '',
  filters: { age: '', category: '' },
  bookmarks: getInitialBookmarks(),
  currentUser: getInitialCurrentUser(),

  // Admin state
  adminToken: getInitialAdminToken(),
  adminEmail: getInitialAdminEmail(),
  adminSearchQuery: '',
  adminSectorFilter: 'All',

  setScreen: (screen) => set({ screen }),

  selectSector: (sector) => set({ screen: 'schemeList', selectedSector: sector, searchQuery: '' }),
  selectScheme: (id) => set({ screen: 'schemeDetail', selectedSchemeId: id }),

  toggleLanguage: () => set((state) => ({ language: state.language === 'en' ? 'hi' : 'en' })),
  setSearchQuery: (query) => set({ searchQuery: query }),
  setFilters: (filters) => set({ filters }),

  toggleBookmark: (id) => {
    const { bookmarks } = get()
    const updated = bookmarks.includes(id) ? bookmarks.filter((b) => b !== id) : [...bookmarks, id]
    if (typeof window !== 'undefined') localStorage.setItem('ypp-bookmarks', JSON.stringify(updated))
    set({ bookmarks: updated })
  },

  isBookmarked: (id) => get().bookmarks.includes(id),

  goBack: () => set((state) => {
    if (state.screen === 'schemeDetail') return { screen: 'schemeList', selectedSchemeId: null }
    if (state.screen === 'schemeList' || state.screen === 'bookmarks') return { screen: 'home', selectedSector: null, searchQuery: '' }
    if (state.screen === 'adminEditScheme') return { screen: 'adminDashboard', selectedSchemeId: null }
    if (state.screen === 'adminAddScheme') return { screen: 'adminDashboard' }
    if (state.screen === 'register' || state.screen === 'signin') return { screen: 'home' }
    return { screen: 'home' }
  }),

  goHome: () => set({ screen: 'home', selectedSector: null, selectedSchemeId: null, searchQuery: '' }),

  // User actions
  setCurrentUser: (user) => {
    if (typeof window !== 'undefined') {
      if (user) localStorage.setItem('ypp-current-user', JSON.stringify(user))
      else localStorage.removeItem('ypp-current-user')
    }
    set({ currentUser: user })
  },

  signOutUser: () => {
    if (typeof window !== 'undefined') localStorage.removeItem('ypp-current-user')
    set({ currentUser: null, screen: 'home' })
  },

  // Admin actions
  setAdminToken: (token) => {
    if (typeof window !== 'undefined') {
      if (token) localStorage.setItem('ypp-admin-token', token)
      else localStorage.removeItem('ypp-admin-token')
    }
    set({ adminToken: token })
  },

  setAdminEmail: (email) => {
    if (typeof window !== 'undefined') {
      if (email) localStorage.setItem('ypp-admin-email', email)
      else localStorage.removeItem('ypp-admin-email')
    }
    set({ adminEmail: email })
  },

  adminLogout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('ypp-admin-token')
      localStorage.removeItem('ypp-admin-email')
    }
    set({ adminToken: null, adminEmail: null, screen: 'home', adminSearchQuery: '', adminSectorFilter: 'All' })
  },

  setAdminSearchQuery: (query) => set({ adminSearchQuery: query }),
  setAdminSectorFilter: (sector) => set({ adminSectorFilter: sector }),
  goToAdminDashboard: () => set({ screen: 'adminDashboard', selectedSchemeId: null, adminSearchQuery: '', adminSectorFilter: 'All' }),
  goToAdminAddScheme: () => set({ screen: 'adminAddScheme' }),
  goToAdminEditScheme: (id) => set({ screen: 'adminEditScheme', selectedSchemeId: id }),
}))
